import React, { useState, useCallback } from 'react';
import ClipCard from './ClipCard';
import type { ClipData } from '../pages/OrganizeClipsPage';

interface ClipLibraryTabsProps {
  activeTab: 'mediamax' | 'ai' | 'upload';
  onTabChange: (tab: 'mediamax' | 'ai' | 'upload') => void;
  clips: ClipData[];
  strategy?: {
    category: string;
    brands: string[];
    objective: string;
    platforms: string[];
  };
}

const ClipLibraryTabs: React.FC<ClipLibraryTabsProps> = ({
  activeTab,
  onTabChange,
  clips,
  strategy
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  // Handle AI clip generation
  const handleGenerateAI = useCallback(async () => {
    setIsGenerating(true);
    // Simulate AI generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsGenerating(false);
    // In real implementation, this would trigger clip generation
  }, []);

  // Handle file upload
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setUploadedFiles(prev => [...prev, ...files]);
  }, []);

  // Handle drag and drop
  const handleDrop = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    const files = Array.from(event.dataTransfer.files);
    setUploadedFiles(prev => [...prev, ...files]);
  }, []);

  const handleDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
  }, []);

  const tabs = [
    {
      id: 'mediamax' as const,
      name: 'Media*MAX',
      icon: '🏢',
      description: 'Top WAT assets matching your strategy',
      color: 'from-blue-500 to-indigo-500'
    },
    {
      id: 'ai' as const,
      name: 'AI Generate',
      icon: '✨',
      description: 'Create clips with VEO3',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'upload' as const,
      name: 'Upload Clips',
      icon: '📁',
      description: 'Your uploaded content',
      color: 'from-green-500 to-emerald-500'
    }
  ];

  return (
    <div className="h-full flex flex-col asset-bank-panel glass-card border border-white/20 rounded-xl">
      {/* Asset Bank Header */}
      <div className="flex-shrink-0 p-4 border-b border-white/10">
        <div className="flex items-center mb-2">
          <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg flex items-center justify-center mr-3">
            <span className="text-sm">🎬</span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-white accessible-text">Asset Bank – Seed Your Modules</h3>
            <p className="text-white/70 text-sm accessible-text">Drag clips from here into the module slots to power the Combination Engine</p>
          </div>
        </div>
      </div>

      {/* Tab Headers */}
      <div className="flex-shrink-0 px-4 pt-2 pb-4">
        <div className="glass-card p-2 border border-white/20 rounded-lg">
          <div className="flex space-x-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 focus-ring ${
                  activeTab === tab.id
                    ? `bg-gradient-to-r ${tab.color} text-white shadow-lg`
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-center">
                  <span className="mr-1">{tab.icon}</span>
                  <span className="hidden sm:inline">{tab.name}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
        
        {/* Tab Description */}
        <div className="mt-2 text-center">
          <p className="text-xs text-white/80 accessibility-enhanced">
            {tabs.find(tab => tab.id === activeTab)?.description}
          </p>
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-hidden px-4 pb-4">
        
        {/* Media*MAX Tab */}
        {activeTab === 'mediamax' && (
          <div className="h-full flex flex-col">
            {strategy && (
              <div className="flex-shrink-0 mb-3 p-3 bg-gradient-to-r from-blue-500/20 to-indigo-500/20 border border-blue-500/30 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-blue-400">🏢</span>
                  <span className="text-white font-medium text-sm">Auto-matched for {strategy.category}</span>
                </div>
                <div className="text-xs text-blue-300">
                  Optimized for {strategy.brands.join(', ')} • {strategy.objective} objective
                </div>
              </div>
            )}
            
            <div className="flex-1 overflow-y-auto">
              {/* Enhanced Responsive Grid Layout */}
              <div className="clip-library-grid">
                {clips.map((clip) => (
                  <ClipCard
                    key={clip.id}
                    clip={clip}
                  />
                ))}
              </div>
              
              {clips.length === 0 && (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center text-white/60 accessible-text">
                    <div className="text-4xl mb-2">🏢</div>
                    <div className="text-sm">No Media*MAX assets found</div>
                    <div className="text-xs">Try adjusting your strategy</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* AI Generate Tab */}
        {activeTab === 'ai' && (
          <div className="h-full flex flex-col">
            <div className="flex-shrink-0 mb-4">
              <button
                onClick={handleGenerateAI}
                disabled={isGenerating}
                className={`w-full p-4 rounded-lg font-medium transition-all focus-ring flex items-center justify-center ${
                  isGenerating
                    ? 'btn-secondary opacity-50 cursor-not-allowed'
                    : 'btn-secondary hover-lift'
                }`}
              >
                {isGenerating ? (
                  <>
                    <div className="btn-spinner"></div>
                    Generating with VEO3...
                  </>
                ) : (
                  <>
                    <span className="mr-2">✨</span>
                    Generate AI Clips
                  </>
                )}
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {/* Show skeleton loaders during AI generation */}
              {isGenerating ? (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  {[...Array(8)].map((_, i) => (
                    <div key={i} className="skeleton-clip-card">
                      <div className="skeleton-thumbnail" />
                      <div className="skeleton-content">
                        <div className="skeleton-line" />
                        <div className="skeleton-line-short" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="clip-library-grid">
                  {clips.map((clip) => (
                    <ClipCard
                      key={clip.id}
                      clip={clip}
                    />
                  ))}
                </div>
              )}
              
              {clips.length === 0 && !isGenerating && (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center text-white/60 accessible-text">
                    <div className="text-4xl mb-2">✨</div>
                    <div className="text-sm">No AI clips generated yet</div>
                    <div className="text-xs">Click above to create with VEO3</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Upload Tab */}
        {activeTab === 'upload' && (
          <div className="h-full flex flex-col">
            
            {/* Upload Area */}
            <div className="flex-shrink-0 mb-4">
              <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                className="glass-card border-2 border-dashed border-white/30 rounded-lg p-6 text-center hover:border-white/50 transition-all cursor-pointer"
              >
                <input
                  type="file"
                  multiple
                  accept="video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <div className="text-3xl mb-2">📁</div>
                  <div className="text-sm text-white font-medium mb-1">
                    Drop files here or click to upload
                  </div>
                  <div className="text-xs text-white/70 accessibility-enhanced">
                    AI will auto-slice longer videos into clips
                  </div>
                </label>
              </div>
            </div>

            {/* Uploaded Files List */}
            {uploadedFiles.length > 0 && (
              <div className="flex-shrink-0 mb-4">
                <div className="text-sm text-white/80 mb-2">Processing uploads:</div>
                <div className="space-y-2">
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-white/5 rounded p-2">
                      <div className="flex items-center">
                        <span className="text-green-400 mr-2">📹</span>
                        <span className="text-sm text-white">{file.name}</span>
                      </div>
                      <div className="text-xs text-white/60">
                        {(file.size / (1024 * 1024)).toFixed(1)}MB
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="flex-1 overflow-y-auto">
              <div className="clip-library-grid">
                {clips.map((clip) => (
                  <ClipCard
                    key={clip.id}
                    clip={clip}
                  />
                ))}
              </div>
              
              {clips.length === 0 && uploadedFiles.length === 0 && (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center text-white/60 accessible-text">
                    <div className="text-4xl mb-2">📁</div>
                    <div className="text-sm">No uploaded clips yet</div>
                    <div className="text-xs">Upload your content to get started</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
      </div>
    </div>
  );
};

export default ClipLibraryTabs;
