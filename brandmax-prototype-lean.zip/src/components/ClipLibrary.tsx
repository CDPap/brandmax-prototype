import React, { useState, useCallback, useMemo } from 'react';

// Strongly-typed module keys
type ModuleKey = 'scroll' | 'brand' | 'education' | 'evidence' | 'cta' | 'audio';

// Enhanced clip interface with duration and engagement data
interface ClipData {
  id: string;
  name: string;
  duration: number; // in seconds
  thumbnail: string;
  module: ModuleKey;
  engagementScore: number; // 0-100, AI-predicted engagement
  isAIGenerated?: boolean;
}

// Module metadata interface
interface ModuleMeta {
  name: string;
  color: string;
  icon: string;
}

// Clip actions for reducer pattern (future implementation)
/*
type ClipAction = 
  | { type: 'ADD_CLIP'; module: ModuleKey; clip: ClipData }
  | { type: 'REMOVE_CLIP'; module: ModuleKey; clipId: string }
  | { type: 'SET_MODULE_CLIPS'; module: ModuleKey; clips: ClipData[] };
*/

// Top-level constants (memoized static data)
const MODULE_KEYS: ModuleKey[] = ['scroll', 'brand', 'education', 'evidence', 'cta', 'audio'];

const MODULE_INFO: Record<ModuleKey, ModuleMeta> = {
  scroll: { name: 'Scroll Stopper', color: 'bg-red-500/20 border-red-400/30', icon: '🎯' },
  brand: { name: 'Brand Builder', color: 'bg-blue-500/20 border-blue-400/30', icon: '🏢' },
  education: { name: 'Education', color: 'bg-green-500/20 border-green-400/30', icon: '🎓' },
  evidence: { name: 'Social Proof', color: 'bg-purple-500/20 border-purple-400/30', icon: '⭐' },
  cta: { name: 'Call to Action', color: 'bg-orange-500/20 border-orange-400/30', icon: '🚀' },
  audio: { name: 'Audio Track', color: 'bg-pink-500/20 border-pink-400/30', icon: '🎵' }
};

interface ClipLibraryProps {
  clipsByModule: Record<ModuleKey, ClipData[]>;
  setClipsByModule: React.Dispatch<React.SetStateAction<Record<ModuleKey, ClipData[]>>>;
}

// Pure component for clip cards (memoized)
interface ClipCardProps {
  clip: ClipData;
  onDragStart: (e: React.DragEvent, clip: ClipData) => void;
}

const ClipCard = React.memo(function ClipCard({ clip, onDragStart }: ClipCardProps) {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, clip)}
      className="glass-card border border-white/20 rounded-lg overflow-hidden hover-lift focus-ring cursor-grab active:cursor-grabbing transition-all hover:border-white/30 hover:shadow-lg"
      aria-label={`${clip.name}, ${clip.duration} seconds, ${clip.engagementScore}% engagement`}
    >
      <div className="aspect-video bg-gray-800/50 relative overflow-hidden">
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-700 to-gray-900">
          <div className="text-center">
            <span className="text-4xl mb-2 block">
              {clip.name.includes('.mp3') ? '🎵' : '🎬'}
            </span>
            <span className="text-xs text-gray-300">Preview</span>
          </div>
        </div>
        <div className="absolute top-2 right-2">
          <span className="bg-black/70 text-white text-xs px-2 py-1 rounded">
            {clip.duration}s
          </span>
        </div>
        <div className="absolute top-2 left-2">
          <div className="flex items-center space-x-1">
            <div 
              className={`w-2 h-2 rounded-full ${
                clip.engagementScore >= 80 ? 'bg-green-400' : 
                clip.engagementScore >= 60 ? 'bg-yellow-400' : 'bg-red-400'
              }`}
              title={`${clip.engagementScore}% engagement score`}
            ></div>
            <span className="text-xs text-white font-bold">{clip.engagementScore}</span>
          </div>
        </div>
        <div className="absolute bottom-2 left-2">
          <div className="flex space-x-1">
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
              <path d="M2 6a2 2 0 012-2h6l2 2h6a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
            </svg>
            {clip.isAIGenerated && (
              <span className="text-xs bg-purple-500 text-white px-1 rounded" aria-label="AI generated">AI</span>
            )}
          </div>
        </div>
      </div>
      <div className="p-3">
        <h4 className="font-medium text-accessible text-sm truncate">
          {clip.name}
        </h4>
        <div className="flex justify-between items-center mt-1">
          <p className="text-accessible-muted text-xs">Ready to use</p>
          <div className="flex items-center space-x-1">
            <span className="text-xs text-accessible-muted">{clip.duration}s</span>
            <div 
              className={`w-1 h-1 rounded-full ${
                clip.engagementScore >= 80 ? 'bg-green-400' : 
                clip.engagementScore >= 60 ? 'bg-yellow-400' : 'bg-red-400'
              }`}
              title={`${clip.engagementScore}% engagement score`}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
});

// Pure component for module buttons (memoized)
interface ModuleButtonProps {
  moduleKey: ModuleKey;
  isSelected: boolean;
  clipCount: number;
  onClick: (module: ModuleKey) => void;
}

const ModuleButton = React.memo(function ModuleButton({ 
  moduleKey, 
  isSelected, 
  clipCount, 
  onClick 
}: ModuleButtonProps) {
  const info = MODULE_INFO[moduleKey];
  
  return (
    <button
      onClick={() => onClick(moduleKey)}
      className={`w-full p-4 rounded-lg border transition-all hover-lift focus-ring text-left ${
        isSelected
          ? `${info.color} shadow-lg`
          : 'glass-card border-white/20 hover:border-white/30'
      }`}
      aria-label={`Select ${info.name} module, ${clipCount} clips`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="text-lg" aria-hidden="true">{info.icon}</span>
          <span className="font-medium text-accessible">{info.name}</span>
        </div>
        <span className="text-sm text-accessible-muted bg-white/10 px-2 py-1 rounded">
          {clipCount}
        </span>
      </div>
    </button>
  );
});

function ClipLibrary({ clipsByModule, setClipsByModule }: ClipLibraryProps) {
  // Future: Replace setClipsByModule with dispatch when implementing reducer pattern
  // const dispatch = useCallback((action: ClipAction) => { ... }, []);
  // Temporarily suppress unused parameter warning
  void setClipsByModule;
  
  const [selectedModule, setSelectedModule] = useState<ModuleKey>('scroll');

  // Memoized computed lists
  const selectedClips = useMemo(
    () => clipsByModule[selectedModule] || [],
    [clipsByModule, selectedModule]
  );

  // Memoized handlers for performance
  const handleDragStart = useCallback(
    (e: React.DragEvent, clip: ClipData) => {
      // Use JSON to pass complete clip data instead of just name
      e.dataTransfer.setData('application/json', JSON.stringify(clip));
    },
    []
  );

  const handleModuleSelect = useCallback((moduleKey: ModuleKey) => {
    setSelectedModule(moduleKey);
  }, []);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="glass-panel p-6 border-b-white-10">
        <h2 className="text-2xl font-bold text-accessible mb-2">Organize Your Clips</h2>
        <p className="text-accessible-muted">
          Select a module category and organize your video clips. Drag clips to the timeline when ready.
        </p>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Module Categories Sidebar */}
        <aside className="w-80 glass-panel border-r-white-10 p-6" role="navigation" aria-label="Content modules">
          <h3 className="text-lg font-semibold text-accessible mb-4">Content Modules</h3>
          <div className="space-y-3">
            {MODULE_KEYS.map((moduleKey) => (
              <ModuleButton
                key={moduleKey}
                moduleKey={moduleKey}
                isSelected={selectedModule === moduleKey}
                clipCount={clipsByModule[moduleKey]?.length || 0}
                onClick={handleModuleSelect}
              />
            ))}
          </div>

          {/* Upload/Generate Section */}
          <div className="mt-8 space-y-3">
            <button 
              className="w-full p-3 glass-card border border-white/20 rounded-lg hover-lift focus-ring text-accessible hover:border-white/30 transition-all"
              aria-label="Upload clips to current module"
            >
              <div className="flex items-center justify-center space-x-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <span>Upload Clips</span>
              </div>
            </button>
            
            <button 
              className="w-full p-3 glass-card border border-white/20 rounded-lg hover-lift focus-ring text-accessible hover:border-white/30 transition-all"
              aria-label="Generate AI clips for current module"
            >
              <div className="flex items-center justify-center space-x-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
                <span>AI Generate</span>
              </div>
            </button>
          </div>
        </aside>

        {/* Clips Grid */}
        <main className="flex-1 p-6">
          <div className="h-full overflow-auto">
            <div className="mb-4">
              <h3 id="clips-heading" className="text-xl font-semibold text-accessible">
                {MODULE_INFO[selectedModule].name} Clips
              </h3>
              <p className="text-accessible-muted mt-1">
                Drag clips to the timeline to add them to your video
              </p>
            </div>

            <section aria-labelledby="clips-heading">
              <ul className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" role="list">
                {selectedClips.map((clip) => (
                  <li key={clip.id}>
                    <ClipCard 
                      clip={clip} 
                      onDragStart={handleDragStart} 
                    />
                  </li>
                ))}
              </ul>
            </section>

            {selectedClips.length === 0 && (
              <div className="text-center py-12">
                <div className="glass-card border border-white/20 rounded-lg p-8">
                  <svg className="w-12 h-12 text-accessible-muted mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4V2a1 1 0 011-1h8a1 1 0 011 1v2M7 4h10M7 4l-2 16h14l-2-16M10 10v4m4-4v4" />
                  </svg>
                  <h3 className="text-lg font-medium text-accessible mb-2">No clips in this module</h3>
                  <p className="text-accessible-muted">Upload or generate clips to get started.</p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default ClipLibrary;
