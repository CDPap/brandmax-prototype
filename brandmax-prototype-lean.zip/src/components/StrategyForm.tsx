import { useState, useCallback } from 'react';
import {
  BRAND_CATEGORIES,
  OBJECTIVES,
  PLATFORMS,
  VOICE_TONES,
  TARGET_AUDIENCES
} from '../config/strategy';

interface StrategyFormProps {
  onNext: () => void;
}

const StrategyForm: React.FC<StrategyFormProps> = ({ onNext }) => {
  // Form State
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [objective, setObjective] = useState<string>('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [voiceTone, setVoiceTone] = useState<string>('');
  const [targetAudience, setTargetAudience] = useState<string>('');

  // Smart validation - only require Brand Category and at least one Brand
  const isFormValid = selectedCategory && selectedBrands.length > 0;

  // Auto-select common products when brand is chosen
  const handleBrandToggle = useCallback((brand: string) => {
    setSelectedBrands(prev => {
      const newBrands = prev.includes(brand) 
        ? prev.filter(b => b !== brand)
        : [...prev, brand];
      
      // Auto-suggest products for first brand
      if (newBrands.length === 1 && !prev.includes(brand)) {
        const commonProducts = BRAND_CATEGORIES[selectedCategory as keyof typeof BRAND_CATEGORIES]?.commonProducts || [];
        setSelectedProducts(commonProducts.slice(0, 2)); // Pre-select first 2 common products
      }
      
      return newBrands;
    });
  }, [selectedCategory]);

  // Platform selection with format info
  const handlePlatformToggle = useCallback((platformId: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(p => p !== platformId)
        : [...prev, platformId]
    );
  }, []);

  return (
    <div className="h-full flex flex-col">
      {/* Top Strategy Summary - Compact Overview */}
      {(selectedCategory || selectedBrands.length > 0 || objective || selectedPlatforms.length > 0) && (
        <div className="glass-card p-3 mb-4 border border-white/20 rounded-lg flex-shrink-0">
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <span className="text-white/80 font-medium accessibility-enhanced">Strategy:</span>
            
            {selectedCategory && (
              <span className="px-2 py-1 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded text-white border border-white/20 text-xs">
                📂 {selectedCategory}
              </span>
            )}
            
            {selectedBrands.length > 0 && (
              <span className="px-2 py-1 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded text-white border border-white/20 text-xs">
                🏢 {selectedBrands.length} brand{selectedBrands.length !== 1 ? 's' : ''}: {selectedBrands.slice(0, 2).join(', ')}{selectedBrands.length > 2 ? ` +${selectedBrands.length - 2}` : ''}
              </span>
            )}
            
            {selectedProducts.length > 0 && (
              <span className="px-2 py-1 bg-gradient-to-r from-green-500/20 to-cyan-500/20 rounded text-white border border-white/20 text-xs">
                📦 {selectedProducts.length} product{selectedProducts.length !== 1 ? 's' : ''}
              </span>
            )}
            
            {objective && (
              <span className="px-2 py-1 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded text-white border border-white/20 text-xs">
                🎯 {OBJECTIVES.find(obj => obj.id === objective)?.label}
              </span>
            )}
            
            {selectedPlatforms.length > 0 && (
              <span className="px-2 py-1 bg-gradient-to-r from-pink-500/20 to-purple-500/20 rounded text-white border border-white/20 text-xs">
                📱 {selectedPlatforms.length} platform{selectedPlatforms.length !== 1 ? 's' : ''}
              </span>
            )}
            
            {voiceTone && (
              <span className="px-2 py-1 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded text-white border border-white/20 text-xs">
                🎭 {VOICE_TONES.find(tone => tone.id === voiceTone)?.label}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Content Grid - Scrollable */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column - Form Cards (70%) */}
        <div className="lg:col-span-2 space-y-4">
          
          {/* 1. Brand Category → Brand Selection - Always Visible */}
          <div className="glass-card p-6 border border-white/20 rounded-xl">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-lg">🏢</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Brand Selection</h3>
                  <p className="text-white/90 text-sm accessibility-enhanced">Choose your category, then select your brands</p>
                </div>
              </div>
              {selectedBrands.length > 0 && (
                <div className="bg-purple-500/20 border border-purple-500/50 rounded-lg px-3 py-1">
                  <span className="text-purple-300 text-sm font-medium">
                    ✓ {selectedBrands.length} brand{selectedBrands.length !== 1 ? 's' : ''} selected
                  </span>
                </div>
              )}
            </div>

            {/* Category Pills */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-white/80 mb-3">Category</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {Object.keys(BRAND_CATEGORIES).map((category) => {
                  const categoryIcons: Record<string, string> = {
                    'Hair Care': '💇‍♀️',
                    'Skin Care': '✨',
                    'Personal Care': '🧴'
                  };
                  
                  return (
                    <button
                      key={category}
                      onClick={() => {
                        setSelectedCategory(category);
                        setSelectedBrands([]); // Reset brands when category changes
                        setSelectedProducts([]); // Reset products too
                      }}
                      className={`group relative p-4 rounded-xl font-medium transition-all duration-300 focus-ring text-sm border-2 ${
                        selectedCategory === category
                          ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-white shadow-xl scale-105 border-cyan-400'
                          : 'glass-card border-white/20 text-white hover:bg-white/10 hover:border-white/40 hover:scale-102'
                      }`}
                      aria-pressed={selectedCategory === category ? 'true' : 'false'}
                    >
                      <div className="text-center">
                        <div className="text-xl mb-1">{categoryIcons[category] || '🏢'}</div>
                        <div className="font-medium text-xs">{category}</div>
                        <div className="text-xs text-white/90 mt-1 accessibility-enhanced">
                          {BRAND_CATEGORIES[category as keyof typeof BRAND_CATEGORIES].brands.length} brands
                        </div>
                      </div>
                      {selectedCategory === category && (
                        <div className="absolute -top-2 -right-2 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Brand Selection */}
            {selectedCategory && (
              <div className="animate-slide-in-up">
                <div className="flex items-center justify-between mb-3">
                  <label className="block text-sm font-medium text-white/80">
                    Select Brands in {selectedCategory}
                  </label>
                  {selectedBrands.length > 0 && (
                    <button 
                      onClick={() => setSelectedBrands([])}
                      className="clear-button-red"
                    >
                      Clear all
                    </button>
                  )}
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {BRAND_CATEGORIES[selectedCategory as keyof typeof BRAND_CATEGORIES].brands.map((brand) => (
                    <button
                      key={brand}
                      onClick={() => handleBrandToggle(brand)}
                      className={`group relative p-4 rounded-xl font-medium transition-all duration-300 focus-ring text-sm border-2 ${
                        selectedBrands.includes(brand)
                          ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-xl scale-105 border-purple-400'
                          : 'glass-card border-white/20 text-white hover:bg-white/10 hover:border-white/40 hover:scale-102'
                      }`}
                      aria-pressed={selectedBrands.includes(brand) ? 'true' : 'false'}
                    >
                      <div className="flex items-center justify-center">
                        <span className="font-medium">{brand}</span>
                      </div>
                      {selectedBrands.includes(brand) && (
                        <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                          <span className="text-white text-xs font-bold">✓</span>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 2. Product Types - Accordion */}
          <details className="glass-card border border-white/20 rounded-xl">
            <summary className="p-6 cursor-pointer">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-lg">📦</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Product Types</h3>
                  <p className="text-white/90 text-sm accessibility-enhanced">Select the products you want to feature (Optional)</p>
                </div>
              </div>
            </summary>
            
            <div className="px-6 pb-6">
              {selectedCategory && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {BRAND_CATEGORIES[selectedCategory as keyof typeof BRAND_CATEGORIES].commonProducts.map((product) => (
                    <button
                      key={product}
                      onClick={() => setSelectedProducts(prev => 
                        prev.includes(product) 
                          ? prev.filter(p => p !== product)
                          : [...prev, product]
                      )}
                      className={`p-3 rounded-lg font-medium transition-all duration-300 focus-ring text-sm ${
                        selectedProducts.includes(product)
                          ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg scale-105'
                          : 'glass-card border border-white/20 text-white hover:bg-white/10'
                      }`}
                      aria-pressed={selectedProducts.includes(product) ? "true" : "false"}
                    >
                      {product}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </details>

          {/* 3. Objective - Accordion */}
          <details className="glass-card border border-white/20 rounded-xl">
            <summary className="p-6 cursor-pointer">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center mr-3">
                    <span className="text-lg">🎯</span>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Campaign Objective</h3>
                    <p className="text-white/90 text-sm accessibility-enhanced">What's your primary goal? (Optional)</p>
                  </div>
                </div>
                {objective && (
                  <div className="bg-orange-500/20 border border-orange-500/50 rounded-lg px-3 py-1">
                    <span className="text-orange-300 text-sm font-medium">✓ Selected</span>
                  </div>
                )}
              </div>
            </summary>
            
            <div className="px-6 pb-6">
              {/* Selection Summary */}
              {objective && (
                <div className="mb-4 p-3 bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-lg">
                  <div className="flex items-center gap-2">
                    <span className="text-orange-400">🎯</span>
                    <span className="text-white font-medium">Selected Objective:</span>
                    <span className="text-orange-300 font-bold">
                      {OBJECTIVES.find(obj => obj.id === objective)?.label}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {OBJECTIVES.map((obj) => (
                  <label
                    key={obj.id}
                    className={`group relative flex flex-col items-center p-5 rounded-xl cursor-pointer transition-all duration-300 focus-ring border-2 ${
                      objective === obj.id
                        ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-xl scale-105 border-orange-400'
                        : 'glass-card border-white/20 text-white hover:bg-white/10 hover:border-white/40 hover:scale-102'
                    }`}
                  >
                    <input
                      type="radio"
                      name="objective"
                      value={obj.id}
                      checked={objective === obj.id}
                      onChange={(e) => setObjective(e.target.value)}
                      className="sr-only"
                    />
                    <span className="text-3xl mb-3">{obj.icon}</span>
                    <div className="text-center">
                      <div className="font-bold text-lg mb-1">{obj.label}</div>
                      <div className="text-sm text-white/90 accessibility-enhanced">{obj.description}</div>
                    </div>
                    {objective === obj.id && (
                      <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-white text-xs font-bold">✓</span>
                      </div>
                    )}
                  </label>
                ))}
              </div>
              
              {objective && (
                <div className="mt-4 flex justify-end">
                  <button 
                    onClick={() => setObjective('')}
                    className="clear-button-red"
                  >
                    Clear selection
                  </button>
                </div>
              )}
            </div>
          </details>

          {/* 4. Platform Selection - Accordion */}
          <details className="glass-card border border-white/20 rounded-xl">
            <summary className="p-6 cursor-pointer">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-lg flex items-center justify-center mr-3">
                    <span className="text-lg">📱</span>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Platforms & Formats</h3>
                    <p className="text-white/90 text-sm accessibility-enhanced">Where will you publish? (Optional)</p>
                  </div>
                </div>
                {selectedPlatforms.length > 0 && (
                  <div className="bg-purple-500/20 border border-purple-500/50 rounded-lg px-3 py-1">
                    <span className="text-purple-300 text-sm font-medium">
                      ✓ {selectedPlatforms.length} platform{selectedPlatforms.length !== 1 ? 's' : ''} selected
                    </span>
                  </div>
                )}
              </div>
            </summary>
            
            <div className="px-6 pb-6">
              {/* Selection Summary */}
              {selectedPlatforms.length > 0 && (
                <div className="mb-4 p-3 bg-gradient-to-r from-purple-500/20 to-indigo-500/20 border border-purple-500/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-purple-400">📱</span>
                    <span className="text-white font-medium">Selected Platforms:</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedPlatforms.map(platformId => {
                      const platform = PLATFORMS.find(p => p.id === platformId);
                      return platform ? (
                        <div key={platformId} className="flex items-center gap-1 bg-purple-500/30 rounded-lg px-2 py-1">
                          <span className="text-sm">{platform.icon}</span>
                          <span className="text-purple-200 text-xs font-medium">{platform.name}</span>
                          <button
                            onClick={() => handlePlatformToggle(platformId)}
                            className="text-purple-200 hover:text-white text-xs ml-1"
                          >
                            ✕
                          </button>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>
              )}

              {/* Platform Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {PLATFORMS.map((platform) => (
                  <button
                    key={platform.id}
                    onClick={() => handlePlatformToggle(platform.id)}
                    className={`group relative p-5 rounded-xl transition-all duration-300 focus-ring text-left border-2 ${
                      selectedPlatforms.includes(platform.id)
                        ? `bg-gradient-to-r ${platform.color} text-white shadow-xl scale-105 border-purple-400`
                        : 'glass-card border-white/20 text-white hover:bg-white/10 hover:border-white/40 hover:scale-102'
                    }`}
                    aria-pressed={selectedPlatforms.includes(platform.id) ? 'true' : 'false'}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <span className="text-xl mr-3">{platform.icon}</span>
                          <span className="font-bold text-base">{platform.name}</span>
                        </div>
                        <div className="text-sm text-white/90 accessibility-enhanced">
                          <div className="mb-1">📐 Format: {platform.format}</div>
                          <div>⏱️ Max: {platform.maxDuration}s</div>
                        </div>
                      </div>
                      
                      {selectedPlatforms.includes(platform.id) && (
                        <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                          <span className="text-white text-xs font-bold">✓</span>
                        </div>
                      )}
                    </div>
                    
                    {/* Selection Indicator */}
                    <div className={`absolute bottom-3 right-3 transition-all duration-300 ${
                      selectedPlatforms.includes(platform.id) 
                        ? 'opacity-100 scale-100' 
                        : 'opacity-0 scale-75 group-hover:opacity-50 group-hover:scale-100'
                    }`}>
                      <div className="w-6 h-6 rounded-full border-2 border-white/50 flex items-center justify-center">
                        {selectedPlatforms.includes(platform.id) && (
                          <div className="w-3 h-3 bg-white rounded-full"></div>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              
              {selectedPlatforms.length > 0 && (
                <div className="mt-4 flex justify-end">
                  <button 
                    onClick={() => setSelectedPlatforms([])}
                    className="clear-button-red"
                  >
                    Clear all platforms
                  </button>
                </div>
              )}
            </div>
          </details>

          {/* 5. Voice & Tone - Accordion */}
          <details className="glass-card border border-white/20 rounded-xl">
            <summary className="p-6 cursor-pointer">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-500 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-lg">🎭</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Voice & Tone</h3>
                  <p className="text-white/90 text-sm accessibility-enhanced">How should your brand sound? (Optional)</p>
                </div>
              </div>
            </summary>
            
            <div className="px-6 pb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {VOICE_TONES.map((voice) => (
                  <label
                    key={voice.id}
                    className={`flex items-center p-4 rounded-lg cursor-pointer transition-all duration-300 focus-ring ${
                      voiceTone === voice.id
                        ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white shadow-lg scale-105'
                        : 'glass-card border border-white/20 text-white hover:bg-white/10'
                    }`}
                  >
                    <input
                      type="radio"
                      name="voiceTone"
                      value={voice.id}
                      checked={voiceTone === voice.id}
                      onChange={(e) => setVoiceTone(e.target.value)}
                      className="sr-only"
                    />
                    <span className="text-lg mr-3">{voice.icon}</span>
                    <span className="font-medium text-sm">{voice.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </details>

          {/* 6. Target Audience - Accordion */}
          <details className="glass-card border border-white/20 rounded-xl">
            <summary className="p-6 cursor-pointer">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-lg">👥</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Target Audience</h3>
                  <p className="text-white/90 text-sm accessibility-enhanced">Who are you trying to reach? (Optional)</p>
                </div>
              </div>
            </summary>
            
            <div className="px-6 pb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {TARGET_AUDIENCES.map((audience) => (
                  <label
                    key={audience.id}
                    className={`p-4 rounded-lg cursor-pointer transition-all duration-300 focus-ring ${
                      targetAudience === audience.id
                        ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-lg scale-105'
                        : 'glass-card border border-white/20 text-white hover:bg-white/10'
                    }`}
                  >
                    <input
                      type="radio"
                      name="targetAudience"
                      value={audience.id}
                      checked={targetAudience === audience.id}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      className="sr-only"
                    />
                    <div className="flex items-start">
                      <span className="text-lg mr-3">{audience.icon}</span>
                      <div>
                        <div className="font-bold text-sm">{audience.label}</div>
                        <div className="text-xs text-white/90 accessibility-enhanced">{audience.description}</div>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </details>
        </div>

        {/* Right Column - Continue Button Only */}
        <div className="space-y-4">
          <div className="sticky top-4">
            {/* Continue Button */}
            <button
              onClick={onNext}
              disabled={!isFormValid}
              className={`w-full px-6 py-3 rounded-lg font-bold transition-all duration-300 focus-ring ${
                isFormValid
                  ? 'btn-primary hover-lift animate-pulse-glow'
                  : 'glass-card border border-white/20 text-white/80 cursor-not-allowed opacity-60 accessibility-enhanced'
              }`}
            >
              {isFormValid ? (
                <>
                  <span className="mr-2">✨</span>
                  Continue
                  <span className="ml-2">→</span>
                </>
              ) : (
                <>
                  <span className="mr-2">🔒</span>
                  Select Category & Brand
                </>
              )}
            </button>
          </div>
        </div>
        </div>
      </div>
    </div>
  );
};

export default StrategyForm;
