import React from 'react';

type ModuleKey = 'scroll' | 'brand' | 'education' | 'evidence' | 'cta' | 'audio';

interface ClipData {
  id: string;
  name: string;
  duration: number;
  thumbnail: string;
  module: ModuleKey;
  engagementScore: number;
  isAIGenerated?: boolean;
}

interface VideoCombination {
  id: string;
  clips: ClipData[];
  estimatedWAT: number;
  totalDuration: number;
  created: Date;
}

type ClipsMap = Record<ModuleKey, ClipData[]>;

interface CombinationControlsProps {
  clipsByModule: ClipsMap;
  combinations: VideoCombination[];
  selectedCombination: VideoCombination | null;
  onGenerateCombinations: () => void;
  onSelectCombination: (combination: VideoCombination) => void;
  maxDuration: number;
}

const CombinationControls: React.FC<CombinationControlsProps> = ({
  clipsByModule,
  combinations,
  selectedCombination,
  onGenerateCombinations,
  onSelectCombination,
  maxDuration
}) => {
  const totalClips = Object.values(clipsByModule).flat().length;

  return (
    <div className="space-y-6">
      {/* Generation Controls */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-accessible">🔄 Generate Combinations</h3>
          <button
            onClick={onGenerateCombinations}
            disabled={totalClips < 5}
            className={`btn-primary px-6 py-3 focus-ring ${totalClips >= 5 ? 'hover-lift' : 'opacity-50 cursor-not-allowed'}`}
          >
            <span className="mr-2" aria-hidden="true">⚡</span>
            Generate Optimal Combinations
          </button>
        </div>
        
        <div className="text-accessible-muted text-sm">
          {totalClips < 5 ? 
            `Add ${5 - totalClips} more clips to generate combinations` :
            `Ready to generate from ${totalClips} clips (max ${maxDuration}s duration)`
          }
        </div>
      </div>

      {/* Combinations Grid */}
      {combinations.length > 0 && (
        <div className="glass-card p-6">
          <h3 className="text-xl font-bold text-accessible mb-4">📊 Generated Combinations</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {combinations.slice(0, 9).map((combination) => (
              <div
                key={combination.id}
                className={`p-4 rounded-lg border cursor-pointer transition-all hover-lift ${
                  selectedCombination?.id === combination.id
                    ? 'border-cinema-gold bg-cinema-gold/10'
                    : 'border-white/20 bg-white/5 hover:border-white/30'
                }`}
                onClick={() => onSelectCombination(combination)}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-accessible font-medium">#{combination.id.split('-')[1]}</span>
                  <span className="text-cinema-gold font-bold text-sm">
                    WAT {combination.estimatedWAT.toFixed(1)}
                  </span>
                </div>
                
                <div className="text-accessible-muted text-xs mb-2">
                  {combination.clips.length} clips • {combination.totalDuration}s
                </div>
                
                <div className="flex items-center space-x-1">
                  {combination.clips.slice(0, 5).map((clip, index) => (
                    <div
                      key={index}
                      className="w-3 h-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
                      title={clip.name}
                    />
                  ))}
                  {combination.clips.length > 5 && (
                    <span className="text-accessible-muted text-xs">+{combination.clips.length - 5}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Selected Combination Preview */}
      {selectedCombination && (
        <div className="glass-card p-6">
          <h3 className="text-xl font-bold text-accessible mb-4">🎬 Selected Combination</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-cinema-gold mb-1">
                {selectedCombination.estimatedWAT.toFixed(1)}
              </div>
              <div className="text-accessible-muted text-sm">WAT Score</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400 mb-1">
                {selectedCombination.totalDuration}s
              </div>
              <div className="text-accessible-muted text-sm">Duration</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-1">
                {selectedCombination.clips.length}
              </div>
              <div className="text-accessible-muted text-sm">Clips</div>
            </div>
          </div>
          
          <div className="mt-4 space-y-2">
            {selectedCombination.clips.map((clip, index) => (
              <div key={clip.id} className="flex items-center justify-between p-2 bg-white/5 rounded">
                <div className="flex items-center space-x-3">
                  <span className="text-accessible-muted text-sm">{index + 1}.</span>
                  <span className="text-accessible text-sm">{clip.name}</span>
                  <span className="text-accessible-muted text-xs">({clip.duration}s)</span>
                </div>
                <span className="text-cinema-gold text-sm font-bold">{clip.engagementScore}%</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CombinationControls;
