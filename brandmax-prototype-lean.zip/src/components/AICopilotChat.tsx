import { useState, useRef, useEffect } from 'react';
import { useCopilot, generateAIResponse } from '../contexts/CopilotContext';
import type { AICommand } from '../contexts/CopilotContext';

interface AICopilotChatProps {
  onExecuteCommand: (command: AICommand) => void;
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
  subtitle?: string;
}

export default function AICopilotChat({ 
  onExecuteCommand, 
  isMinimized = false, 
  onToggleMinimize,
  subtitle
}: AICopilotChatProps) {
  const { state, actions } = useCopilot();
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.messages, state.isTyping]);

  useEffect(() => {
    if (state.isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [state.isOpen]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue.trim();
    setInputValue('');

    // Add user message
    actions.addMessage({
      type: 'user',
      content: userMessage,
    });

    // Show typing indicator
    actions.setTyping(true);

    try {
      // Generate AI response
      const response = await generateAIResponse(userMessage);
      
      // Add AI message
      actions.addMessage({
        type: 'ai',
        content: response.content,
        commands: response.commands,
      });

      // Execute any commands
      if (response.commands) {
        response.commands.forEach((command) => {
          onExecuteCommand(command);
        });
      }
    } catch (error) {
      actions.addMessage({
        type: 'ai',
        content: "I'm sorry, I encountered an error. Please try again.",
      });
    } finally {
      actions.setTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageContent = (content: string) => {
    // Simple markdown-like formatting
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>');
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-slate-900/50 to-purple-900/30 relative">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        {!isMinimized ? (
          <>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <span className="text-lg">🤖</span>
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">AI Copilot</h3>
                <p className="text-xs text-white/80 accessibility-enhanced">
                  {subtitle || 'Interactive Strategy Assistant'}
                </p>
              </div>
            </div>
            <button
              onClick={onToggleMinimize}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white/80 hover:text-white accessibility-enhanced"
              title="Minimize"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
              </svg>
            </button>
          </>
        ) : (
          <button
            onClick={onToggleMinimize}
            className="w-full flex flex-col items-center py-3 hover:bg-white/20 rounded-lg transition-all duration-200 text-white hover:text-white border border-white/20 hover:border-white/40 bg-black/20 hover:bg-black/30"
            title="Expand AI Copilot"
          >
            <div className="w-6 h-6 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center mb-1 shadow-lg">
              <span className="text-sm">🤖</span>
            </div>
            <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}
      </div>

      {/* Main Content - Only show when not minimized */}
      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollable-content">
        {state.messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] p-3 rounded-2xl ${
                message.type === 'user'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white ml-4'
                  : 'glass-card border border-white/20 text-white mr-4'
              }`}
            >
              <div
                className="text-sm leading-relaxed"
                dangerouslySetInnerHTML={{
                  __html: formatMessageContent(message.content),
                }}
              />
              {message.commands && message.commands.length > 0 && (
                <div className="mt-2 pt-2 border-t border-white/20">
                  <div className="text-xs text-white/80 mb-1 accessibility-enhanced">Actions executed:</div>
                  <div className="space-y-1">
                    {message.commands.map((cmd, idx) => (
                      <div key={idx} className="text-xs bg-white/10 px-2 py-1 rounded">
                        {cmd.command}: {cmd.value}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="text-xs text-white/70 mt-2 accessibility-enhanced">
                {message.timestamp.toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </div>
            </div>
          </div>
        ))}

        {state.isTyping && (
          <div className="flex justify-start">
            <div className="glass-card border border-white/20 text-white mr-4 p-3 rounded-2xl">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce bounce-delay-1"></div>
                <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce bounce-delay-2"></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t-white-10">
        <div className="flex items-end space-x-2">
          <div className="flex-1">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me to help with your strategy..."
              className="w-full p-3 glass-card border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:border-transparent resize-none"
              disabled={state.isTyping}
            />
          </div>
          <button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || state.isTyping}
            className="p-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-xl hover:from-cyan-600 hover:to-blue-600 transition-all hover-lift focus-ring disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
            aria-label="Send message"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"
              />
            </svg>
          </button>
        </div>

        {/* Quick suggestions */}
        <div className="mt-3 flex flex-wrap gap-2">
          {[
            "Set up hair care campaign",
            "Suggest beauty brands",
            "Configure for TikTok",
            "Make it playful and fun"
          ].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => setInputValue(suggestion)}
              className="text-xs px-3 py-1 glass-card border border-white/20 rounded-full text-white/80 hover:text-white hover:border-white/40 transition-all"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>
        </>
      )}
    </div>
  );
}
