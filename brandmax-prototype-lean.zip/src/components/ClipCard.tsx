import React, { useCallback } from 'react';
import type { ClipData, ModuleType } from '../pages/OrganizeClipsPage';

interface ClipCardProps {
  clip: ClipData;
}

const ClipCard: React.FC<ClipCardProps> = ({ clip }) => {
  // Enhanced drag start with visual feedback
  const handleDragStart = useCallback((e: React.DragEvent) => {
    e.dataTransfer.setData('application/json', JSON.stringify({
      clipId: clip.id,
      clipName: clip.name
    }));
    e.dataTransfer.effectAllowed = 'copy';
    
    // Add visual feedback class to body during drag
    document.body.classList.add('dragging-clip');
  }, [clip.id, clip.name]);

  const handleDragEnd = useCallback(() => {
    document.body.classList.remove('dragging-clip');
  }, []);

  // Get suggested module based on tags
  const getSuggestedModule = (): ModuleType | null => {
    const tags = clip.tags || [];
    
    if (tags.includes('hook') || tags.includes('scroll-stopper')) return 'scroll';
    if (tags.includes('brand') || tags.includes('logo')) return 'brand';
    if (tags.includes('education') || tags.includes('demo')) return 'education';
    if (tags.includes('testimonial') || tags.includes('social-proof')) return 'proof';
    if (tags.includes('cta') || tags.includes('call-to-action')) return 'cta';
    if (tags.includes('audio') || tags.includes('music')) return 'audio';
    
    return null;
  };

  const suggestedModule = getSuggestedModule();

  // Get WAT score color and glow class
  const getWATColor = (score: number) => {
    if (score >= 90) return 'text-green-400';
    if (score >= 80) return 'text-yellow-400';
    if (score >= 70) return 'text-orange-400';
    return 'text-red-400';
  };

  const getWATGlow = (score: number) => {
    if (score >= 90) return 'wat-glow-green';
    if (score >= 80) return 'wat-glow-yellow';
    if (score >= 70) return 'wat-glow-orange';
    return 'wat-glow-red';
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      className={`clip-card-enhanced cursor-grab active:cursor-grabbing group hover:${getWATGlow(clip.watScore)} transition-all duration-300 hover:scale-105`}
      role="button"
      tabIndex={0}
      aria-label={`Drag ${clip.name} clip to a module slot. WAT score: ${Math.round(clip.watScore)}, Duration: ${clip.duration}s`}
    >
      {/* Thumbnail */}
      <div className="relative">
        <img
          src={clip.thumbnail}
          alt={clip.name}
          className="clip-card-thumbnail"
        />
        
        {/* Drag Handle - Always Visible */}
        <div className="clip-card-drag-handle">
          ☰
        </div>
        
        {/* WAT Score Badge - Top Left */}
        <div className="clip-card-wat-badge">
          ⭐ {Math.round(clip.watScore)}
        </div>
        
        {/* Duration Badge - Top Right */}
        <div className="clip-card-duration">
          {clip.duration}s
        </div>
        
        {/* Source Badges - Bottom Right (hover only) */}
        <div className="clip-card-badges">
          {clip.isAIGenerated && (
            <div className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white text-xs px-2 py-1 rounded-full font-bold">
              🤖 AI
            </div>
          )}
          {clip.isMediaMax && (
            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white text-xs px-2 py-1 rounded-full font-bold">
              � Pin
            </div>
          )}
        </div>

        {/* Play Button Overlay (appears on hover) */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none">
          <div className="w-12 h-12 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white">
            <span className="text-xl ml-0.5">▶</span>
          </div>
        </div>

        {/* Drag Handle */}
        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="bg-white/20 backdrop-blur-sm text-white text-xs px-1.5 py-0.5 rounded border border-white/20">
            ⋮⋮
          </div>
        </div>
      </div>

      {/* Clip Info */}
      <div className="mb-3">
        <h4 className="text-sm font-medium text-white truncate mb-1 group-hover:text-yellow-200 transition-colors">
          {clip.name}
        </h4>
        
        {/* WAT Score & Performance Indicators */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              <span className="text-white/60">WAT:</span>
              <span className={`ml-1 font-bold ${getWATColor(clip.watScore)} ${clip.watScore > 90 ? 'animate-pulse' : ''}`}>
                {clip.watScore.toFixed(1)}
              </span>
              {clip.watScore > 85 && (
                <span className="ml-1 text-yellow-400 animate-bounce">⭐</span>
              )}
            </div>
            
            {/* Performance Badge */}
            {clip.watScore > 90 && (
              <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs px-1.5 py-0.5 rounded font-bold">
                TOP 10%
              </div>
            )}
          </div>
          
          {/* Pin Icon for favorites */}
          <div
            className="text-white/40 hover:text-yellow-400 transition-colors p-0.5 transform hover:scale-110"
            aria-label="Pin clip"
          >
            📌
          </div>
        </div>
      </div>

      {/* Tags */}
      {clip.tags && clip.tags.length > 0 && (
        <div className="mb-3">
          <div className="flex flex-wrap gap-1">
            {clip.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="text-xs bg-white/10 text-white/80 px-1.5 py-0.5 rounded"
              >
                {tag}
              </span>
            ))}
            {clip.tags.length > 3 && (
              <span className="text-xs text-white/60">
                +{clip.tags.length - 3}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="flex items-center justify-between">
        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          {/* Preview Button */}
          <div
            className="text-white/60 hover:text-white transition-all duration-300 p-1 hover:scale-110 pointer-events-none"
            aria-label={`Preview ${clip.name}`}
          >
            <span className="text-sm">▶️</span>
          </div>
          
          {/* AI Badge for AI-generated content */}
          {clip.isAIGenerated && (
            <div className="bg-gradient-to-r from-purple-500/20 to-indigo-500/20 border border-purple-400/30 text-purple-300 text-xs px-1.5 py-0.5 rounded">
              🤖 AI
            </div>
          )}
        </div>

        {/* Quick Assign Button */}
        {suggestedModule && (
          <div
            className="text-xs bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-cyan-300 px-2 py-1 rounded hover:from-cyan-500/30 hover:to-blue-500/30 transition-all transform hover:scale-105 pointer-events-none"
            title={`Quick assign to ${suggestedModule}`}
          >
            ⚡ {suggestedModule}
          </div>
        )}
      </div>

      {/* Enhanced Drag Helper Text */}
      <div className="mt-2 text-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
        <div className="text-xs text-white/50 italic">
          {suggestedModule ? 
            `🎯 Suggested for ${suggestedModule} module` : 
            "Drag to any module or use AI suggestions"
          }
        </div>
      </div>
    </div>
  );
};

export default ClipCard;
