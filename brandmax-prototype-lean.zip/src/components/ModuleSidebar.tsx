import React, { useState } from 'react';
import type { ModuleInfo, ModuleType, ClipData } from '../pages/OrganizeClipsPage';

interface ModuleSidebarProps {
  modules: ModuleInfo[];
  moduleClips: Record<ModuleType, ClipData[]>;
  onClipRemove: (clipId: string, moduleId: ModuleType) => void;
}

const ModuleSidebar: React.FC<ModuleSidebarProps> = ({ 
  modules, 
  moduleClips, 
  onClipRemove 
}) => {
  const [expandedModules, setExpandedModules] = useState<Set<ModuleType>>(
    new Set(modules.filter(m => moduleClips[m.id]?.length > 0).map(m => m.id))
  );

  const toggleModule = (moduleId: ModuleType) => {
    const newExpanded = new Set(expandedModules);
    if (newExpanded.has(moduleId)) {
      newExpanded.delete(moduleId);
    } else {
      newExpanded.add(moduleId);
    }
    setExpandedModules(newExpanded);
  };

  // Simplified module classes - CSS handles all styling
  const getModuleClasses = (moduleId: ModuleType, clipCount: number) => {
    const baseClasses = "module-accordion-row relative transition-all duration-300 cursor-pointer rounded-lg overflow-hidden";
    const moduleClass = `module-${moduleId}`;
    const seededEffects = clipCount > 0 
      ? 'ring-2 ring-white/20 shadow-2xl transform hover:scale-[1.02]' 
      : 'hover:scale-[1.01]';
      
    return `${baseClasses} ${moduleClass} ${seededEffects}`;
  };

  return (
    <div className="glass-card p-4 border border-white/20 rounded-xl">
      <div className="flex items-center mb-4">
        <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-lg flex items-center justify-center mr-3">
          <span className="text-sm">📁</span>
        </div>
        <div>
          <h3 className="text-lg font-bold text-white accessible-text">Module Library</h3>
          <p className="text-white/90 text-sm accessible-text">Organize clips by purpose</p>
        </div>
      </div>

      <div className="space-y-2">
        {modules.map((module) => {
          const clipCount = moduleClips[module.id]?.length || 0;
          const clips = moduleClips[module.id] || [];
          const isExpanded = expandedModules.has(module.id);
          const hasClips = clipCount > 0;
          
          return (
            <div 
              key={module.id}
              className={`${getModuleClasses(module.id, clipCount)} ${isExpanded ? 'module-accordion-expanded' : ''}`}
              data-module={module.id}
            >
              <button
                onClick={() => toggleModule(module.id)}
                className="w-full h-full flex items-center justify-between text-left focus:outline-none focus:ring-2 focus:ring-white/50 rounded-lg"
                aria-expanded={isExpanded ? "true" : "false"}
                aria-controls={`module-${module.id}-content`}
              >
                <div className="flex items-center justify-between w-full px-4 py-3">
                  <div className="flex items-center">
                    {/* Module Drag Handle */}
                    <div className="text-white/60 hover:text-white mr-3 transition-colors">
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                        <circle cx="2" cy="3" r="1"/>
                        <circle cx="6" cy="3" r="1"/>
                        <circle cx="10" cy="3" r="1"/>
                        <circle cx="2" cy="6" r="1"/>
                        <circle cx="6" cy="6" r="1"/>
                        <circle cx="10" cy="6" r="1"/>
                        <circle cx="2" cy="9" r="1"/>
                        <circle cx="6" cy="9" r="1"/>
                        <circle cx="10" cy="9" r="1"/>
                      </svg>
                    </div>
                    <span className="text-2xl mr-4 filter drop-shadow-lg">{module.icon}</span>
                    <div>
                      <div className="text-sm font-semibold accessible-text">{module.name}</div>
                      {!isExpanded && clipCount > 0 && (
                        <div className="text-xs accessible-text opacity-80">{clipCount} clips seeded</div>
                      )}
                      {!isExpanded && clipCount === 0 && (
                        <div className="text-xs text-white/50 accessible-text">Empty module</div>
                      )}
                    </div>
                  </div>
                  
                  {/* Enhanced Seed Counter with WCAG Contrast */}
                  <div className={`px-3 py-1 rounded-full text-xs font-bold transition-all duration-300 ${
                    clipCount > 0 
                      ? 'bg-green-600 text-white shadow-lg ring-1 ring-green-400/50' 
                      : 'bg-gray-700 text-gray-300 border border-gray-600'
                  }`}>
                    {clipCount}/∞
                  </div>
                </div>
              </button>

              {/* Expandable Content */}
              {isExpanded && (
                <div 
                  id={`module-${module.id}-content`}
                  className="px-3 pb-3 animate-fadeIn"
                >
                  {hasClips ? (
                    <div className="space-y-2 max-h-40 overflow-y-auto scrollbar-thin">
                      {clips.map((clip) => (
                        <div 
                          key={clip.id}
                          className="flex items-center justify-between bg-white/5 rounded p-2 text-xs group hover:bg-white/10 transition-colors"
                        >
                          <div className="flex items-center min-w-0 flex-1">
                            <div className="w-8 h-6 bg-gradient-to-r from-gray-600 to-gray-700 rounded mr-2 flex-shrink-0 flex items-center justify-center">
                              {clip.isAIGenerated && <span className="text-xs text-purple-300">🤖</span>}
                              {clip.isMediaMax && <span className="text-xs text-blue-300">⭐</span>}
                              {!clip.isAIGenerated && !clip.isMediaMax && <span className="text-xs text-green-300">📁</span>}
                            </div>
                            <div className="truncate">
                              <div className="text-white font-medium accessible-text">{clip.name}</div>
                              <div className="text-white/60 accessible-text">
                                {clip.duration}s • WAT {clip.watScore.toFixed(1)}
                                {clip.watScore > 85 && <span className="text-yellow-400 ml-1">⭐</span>}
                              </div>
                            </div>
                          </div>
                          
                          <button
                            onClick={() => onClipRemove(clip.id, module.id)}
                            className="ml-2 text-white/50 hover:text-red-400 transition-colors focus-ring p-1 opacity-0 group-hover:opacity-100"
                            aria-label={`Remove ${clip.name} from ${module.name}`}
                          >
                            ×
                          </button>
                        </div>
                      ))}
                      
                      {/* Module Stats */}
                      <div className="mt-2 pt-2 border-t border-white/10 text-xs text-white/70 accessible-text">
                        <div className="flex justify-between">
                          <span>Total: {clips.reduce((sum, clip) => sum + clip.duration, 0)}s</span>
                          <span>Avg WAT: {(clips.reduce((sum, clip) => sum + clip.watScore, 0) / clips.length).toFixed(1)}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-white/60 accessible-text">
                      <div className="text-2xl mb-2">{module.icon}</div>
                      <div className="text-xs">No clips added yet</div>
                      <div className="text-xs mt-1 italic">{module.description}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ModuleSidebar;
