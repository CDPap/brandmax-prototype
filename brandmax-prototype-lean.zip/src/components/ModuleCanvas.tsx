import React, { useCallback, useState } from 'react';
import type { ModuleInfo, ModuleType, ClipData } from '../pages/OrganizeClipsPage';

interface ModuleCanvasProps {
  modules: ModuleInfo[];
  moduleClips: Record<ModuleType, ClipData[]>;
  onClipAssign: (clipId: string, moduleId: ModuleType) => void;
  onClipRemove: (clipId: string, moduleId: ModuleType) => void;
}

const ModuleCanvas: React.FC<ModuleCanvasProps> = ({
  modules,
  moduleClips,
  onClipAssign,
  onClipRemove
}) => {
  const [dragOverModule, setDragOverModule] = useState<ModuleType | null>(null);

  // Handle drop on module
  const handleDrop = useCallback((e: React.DragEvent, moduleId: ModuleType) => {
    e.preventDefault();
    setDragOverModule(null);
    
    try {
      const data = JSON.parse(e.dataTransfer.getData('application/json'));
      if (data.clipId) {
        onClipAssign(data.clipId, moduleId);
      }
    } catch (error) {
      console.error('Invalid drop data:', error);
    }
  }, [onClipAssign]);

  const handleDragOver = useCallback((e: React.DragEvent, moduleId: ModuleType) => {
    e.preventDefault();
    setDragOverModule(moduleId);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOverModule(null);
  }, []);

  return (
    <div className="h-full flex flex-col module-slot-panel">
      <div className="glass-card p-4 border border-white/20 rounded-xl mb-4 flex-shrink-0 hover-3d">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center mr-3">
              <span className="text-sm">🎬</span>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Module Canvas – Target Slots</h3>
              <p className="text-white/70 text-sm accessibility-enhanced">Drop clips here to build your video combinations</p>
            </div>
          </div>
          
          {/* Rule of Thirds Toggle */}
          <button 
            className="btn-tertiary text-xs px-3 py-1"
            title="Toggle Rule of Thirds viewfinder"
          >
            📐 Viewfinder
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 film-grain relative">
        {modules.map((module) => {
          const clips = moduleClips[module.id] || [];
          const isHighlighted = dragOverModule === module.id;
          
          return (
            <div
              key={module.id}
              onDrop={(e) => handleDrop(e, module.id)}
              onDragOver={(e) => handleDragOver(e, module.id)}
              onDragLeave={handleDragLeave}
              className={`glass-card border-2 rounded-xl p-4 transition-all duration-300 hover-3d ${
                isHighlighted
                  ? `border-gradient bg-gradient-to-r ${module.color} border-opacity-60 shadow-xl scale-105 module-glow`
                  : 'border-white/20 hover:border-white/40'
              }`}
            >
              {/* Module Header with Seed Counter */}
              <div className="drop-zone-header">
                <div className="flex items-center">
                  <span className="text-xl mr-3 transition-transform duration-300 hover:scale-110">{module.icon}</span>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-white font-bold text-sm accessible-text">{module.name}</h4>
                      {/* Live Totals */}
                      {clips.length > 0 && (
                        <div className="zone-stats accessible-text">
                          Total: {clips.length} clips | {clips.reduce((sum, clip) => sum + clip.duration, 0)}s
                        </div>
                      )}
                    </div>
                    <p className="text-white/60 text-xs accessible-text">{module.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {/* Suggest Clip Button */}
                  <button
                    className="btn-tertiary text-xs px-2 py-1"
                    title={`AI suggest ${module.name.toLowerCase()} clips`}
                  >
                    🤖 Suggest
                  </button>
                  
                  {/* Seed Counter Badge */}
                  <div className={`seed-counter-badge ${clips.length > 0 ? 'has-clips' : ''}`}>
                    {clips.length}/∞ seeded
                  </div>
                </div>
              </div>

              {/* Enhanced Drop Zone with Ghost Preview */}
              <div className={`drop-zone-enhanced min-h-[80px] relative transition-all duration-300 ${
                isHighlighted
                  ? `border-white/60 bg-white/10 module-${module.id}-glow`
                  : 'border-white/20 hover:border-white/30'
              }`}
              role="region"
              aria-label={`${module.name} drop zone`}
              >
                
                {/* Ghost Preview (shows when dragging over) */}
                {isHighlighted && (
                  <div className="ghost-preview">
                    📄
                  </div>
                )}
                
                {clips.length === 0 ? (
                  // Empty drop zone
                  <div className="h-20 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl mb-1 transition-transform duration-300 hover:scale-110">{module.icon}</div>
                      <div className="text-xs text-white/60 accessible-text">
                        Drop {module.name.toLowerCase()} clips here
                      </div>
                    </div>
                  </div>
                ) : (
                  // Mini Preview Thumbnails (50×28px)
                  <div className="p-2">
                    <div className="flex space-x-2 overflow-x-auto scrollbar-thin" role="list" aria-label={`${module.name} clips`}>
                      {clips.map((clip) => (
                        <div
                          key={clip.id}
                          className="flex-shrink-0 w-12 group clip-pop"
                          role="listitem"
                          aria-label={`${clip.name} preview`}
                        >
                          <div className="relative">
                            <img
                              src={clip.thumbnail}
                              alt={clip.name}
                              className="w-12 h-7 object-cover rounded bg-gradient-to-r from-gray-600 to-gray-700"
                            />
                            
                            {/* Tiny WAT Badge */}
                            <div className="absolute -top-1 -right-1 bg-black/90 text-white text-xs px-1 rounded-full leading-none">
                              ⭐
                            </div>
                            
                            {/* 3-Star WAT Badge */}
                            <div className="absolute top-0.5 left-0.5">
                              {clip.watScore > 90 ? (
                                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs px-1.5 py-0.5 rounded font-bold flex items-center">
                                  ⭐⭐⭐ {clip.watScore.toFixed(1)}
                                </div>
                              ) : clip.watScore > 80 ? (
                                <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-black text-xs px-1.5 py-0.5 rounded font-bold flex items-center">
                                  ⭐⭐ {clip.watScore.toFixed(1)}
                                </div>
                              ) : clip.watScore > 70 ? (
                                <div className="bg-gradient-to-r from-yellow-500 to-orange-400 text-white text-xs px-1.5 py-0.5 rounded font-bold flex items-center">
                                  ⭐ {clip.watScore.toFixed(1)}
                                </div>
                              ) : (
                                <div className="bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                                  {clip.watScore.toFixed(1)}
                                </div>
                              )}
                            </div>
                            
                            {/* Remove button */}
                            <button
                              onClick={() => onClipRemove(clip.id, module.id)}
                              className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity focus-ring"
                              aria-label={`Remove ${clip.name}`}
                            >
                              ×
                            </button>
                            
                            {/* Preview button */}
                            <button
                              className="absolute inset-0 bg-black/0 hover:bg-black/50 text-white opacity-0 hover:opacity-100 transition-all flex items-center justify-center focus-ring rounded"
                              aria-label={`Preview ${clip.name}`}
                            >
                              <span className="text-lg">▶️</span>
                            </button>
                            
                            {/* Pin icon (bottom-right, appears on hover) */}
                            <button
                              className="absolute bottom-0.5 left-0.5 text-white/60 hover:text-yellow-400 transition-colors opacity-0 group-hover:opacity-100 focus-ring"
                              aria-label={`Pin ${clip.name}`}
                            >
                              📌
                            </button>
                          </div>
                          
                          <div className="mt-1">
                            <div className="text-xs text-white font-medium truncate accessible-text">
                              {clip.name}
                            </div>
                            <div className="text-xs text-white/60 accessible-text">
                              WAT {clip.watScore.toFixed(1)}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Module Stats */}
              {clips.length > 0 && (
                <div className="mt-3 flex items-center justify-between text-xs">
                  <div className="text-white/70 accessibility-enhanced">
                    Total: {clips.reduce((sum, clip) => sum + clip.duration, 0)}s
                  </div>
                  <div className="text-white/70 accessibility-enhanced">
                    Avg WAT: {(clips.reduce((sum, clip) => sum + clip.watScore, 0) / clips.length).toFixed(1)}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ModuleCanvas;