// Strategy Configuration - Procter & Gamble Beauty Brands
export const BRAND_CATEGORIES = {
  'Hair Care': {
    brands: ['Pantene', 'Head & Shoulders', 'Herbal Essences', 'Aussie', 'Olay Hair'],
    commonProducts: ['Shampoo', 'Conditioner', 'Hair Mask', 'Dry Shampoo', 'Hair Oil']
  },
  'Skin Care': {
    brands: ['Olay', 'SK-II', 'Oil of Olay', 'Olay Regenerist', 'Olay Total Effects'],
    commonProducts: ['Cleanser', 'Moisturizer', 'Serum', 'Sunscreen', 'Face Mask']
  },
  'Personal Care': {
    brands: ['Old Spice', 'Gillette', 'Venus', 'Braun', 'Oral-B'],
    commonProducts: ['Body Wash', 'Deodorant', 'Razors', 'Shaving Cream', 'Toothpaste']
  }
} as const;

export const OBJECTIVES = [
  { id: 'build', label: 'Build', icon: '🏗️', description: 'Build brand awareness' },
  { id: 'remind', label: 'Remind', icon: '🔔', description: 'Remind customers of your brand' },
  { id: 'buy', label: 'Buy', icon: '🛒', description: 'Drive immediate purchases' }
] as const;

export const PLATFORMS = [
  { id: 'tiktok', name: 'TikTok', icon: '🎵', format: '9:16', maxDuration: 60, color: 'from-pink-500 to-red-500' },
  { id: 'instagram', name: 'Instagram Reels', icon: '📸', format: '9:16', maxDuration: 90, color: 'from-purple-500 to-pink-500' },
  { id: 'youtube', name: 'YouTube Shorts', icon: '📺', format: '9:16', maxDuration: 60, color: 'from-red-500 to-orange-500' },
  { id: 'facebook', name: 'Facebook', icon: '👥', format: '16:9', maxDuration: 120, color: 'from-blue-500 to-indigo-500' }
] as const;

export const VOICE_TONES = [
  { id: 'influencer', label: 'Influencer', icon: '🌟' },
  { id: 'expert', label: 'Expert', icon: '👨‍⚕️' },
  { id: 'community', label: 'Community', icon: '👥' },
  { id: 'brand', label: 'Brand', icon: '🏢' }
] as const;

export const TARGET_AUDIENCES = [
  { id: 'gen-z', label: 'Gen Z (18-24)', icon: '🎮', description: 'Digital natives, authenticity-focused' },
  { id: 'millennials', label: 'Millennials (25-40)', icon: '💼', description: 'Value-conscious, brand loyal' },
  { id: 'gen-x', label: 'Gen X (41-56)', icon: '🏠', description: 'Family-focused, practical' },
  { id: 'boomers', label: 'Baby Boomers (57+)', icon: '🌱', description: 'Traditional, quality-focused' }
] as const;

export type BrandCategory = keyof typeof BRAND_CATEGORIES;
export type ObjectiveId = typeof OBJECTIVES[number]['id'];
export type PlatformId = typeof PLATFORMS[number]['id'];
export type VoiceToneId = typeof VOICE_TONES[number]['id'];
export type TargetAudienceId = typeof TARGET_AUDIENCES[number]['id'];

export interface StrategyData {
  category: string;
  brands: string[];
  products: string[];
  objective: ObjectiveId;
  platforms: PlatformId[];
  voiceTone: VoiceToneId;
  targetAudience: TargetAudienceId;
}
