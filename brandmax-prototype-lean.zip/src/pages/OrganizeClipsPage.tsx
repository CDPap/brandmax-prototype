import React, { useState, useMemo, useCallback, useEffect } from 'react';
import ModuleSidebar from '../components/ModuleSidebar';
import ClipLibraryTabs from '../components/ClipLibraryTabs';
import ModuleCanvas from '../components/ModuleCanvas';
import AICopilotChat from '../components/AICopilotChat';
import type { AICommand } from '../contexts/CopilotContext';

// Types for clip organization
export type ModuleType = 'scroll' | 'brand' | 'education' | 'proof' | 'cta' | 'audio';

export interface ClipData {
  id: string;
  name: string;
  thumbnail: string;
  duration: number;
  watScore: number;
  isAIGenerated?: boolean;
  isMediaMax?: boolean;
  tags: string[];
  module?: ModuleType;
}

export interface ModuleInfo {
  id: ModuleType;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export const MODULES: ModuleInfo[] = [
  {
    id: 'scroll',
    name: 'Scroll Stopper',
    icon: '🎯',
    color: 'from-cyan-500 to-blue-500',
    description: 'Hook viewers in the first 3 seconds'
  },
  {
    id: 'brand',
    name: 'Brand Builder',
    icon: '👑',
    color: 'from-purple-500 to-violet-500',
    description: 'Showcase your brand identity'
  },
  {
    id: 'education',
    name: 'Education',
    icon: '🧠',
    color: 'from-emerald-500 to-green-500',
    description: 'Provide valuable information'
  },
  {
    id: 'proof',
    name: 'Social Proof',
    icon: '🏆',
    color: 'from-amber-500 to-orange-500',
    description: 'Show testimonials and reviews'
  },
  {
    id: 'cta',
    name: 'Call to Action',
    icon: '�',
    color: 'from-rose-500 to-red-500',
    description: 'Drive specific actions'
  },
  {
    id: 'audio',
    name: 'Audio Track',
    icon: '�',
    color: 'from-indigo-500 to-blue-600',
    description: 'Background music and sound'
  }
];

interface OrganizeClipsPageProps {
  strategy?: {
    category: string;
    brands: string[];
    objective: string;
    platforms: string[];
    voiceTone?: string;
    targetAudience?: string;
  };
  onNext: () => void;
}

const OrganizeClipsPage: React.FC<OrganizeClipsPageProps> = ({ strategy, onNext }) => {
  // Module assignments state
  const [moduleClips, setModuleClips] = useState<Record<ModuleType, ClipData[]>>({
    scroll: [],
    brand: [],
    education: [],
    proof: [],
    cta: [],
    audio: []
  });

  // Active library tab
  const [activeTab, setActiveTab] = useState<'mediamax' | 'ai' | 'upload'>('mediamax');

  // AI Copilot state
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [copilotWidth, setCopilotWidth] = useState(384);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isResizing, setIsResizing] = useState(false);

  // Mock data for demonstration
  const mockClips = useMemo(() => {
    const clips: ClipData[] = [];
    
    // MediaMAX clips (auto-populated based on strategy)
    if (strategy?.category) {
      const categoryClips = [
        {
          id: 'mm-1',
          name: `${strategy.category} Hero Shot`,
          thumbnail: '/api/placeholder/200/112',
          duration: 15,
          watScore: 92.5,
          isMediaMax: true,
          tags: ['hero', 'product', strategy.category.toLowerCase()],
        },
        {
          id: 'mm-2',
          name: `${strategy.brands[0]} Lifestyle`,
          thumbnail: '/api/placeholder/200/112',
          duration: 12,
          watScore: 88.3,
          isMediaMax: true,
          tags: ['lifestyle', 'brand', strategy.brands[0].toLowerCase()],
        },
        {
          id: 'mm-3',
          name: 'Customer Testimonial',
          thumbnail: '/api/placeholder/200/112',
          duration: 18,
          watScore: 85.7,
          isMediaMax: true,
          tags: ['testimonial', 'social-proof'],
        }
      ];
      clips.push(...categoryClips);
    }

    // AI Generated clips
    const aiClips = [
      {
        id: 'ai-1',
        name: 'AI Generated Hook',
        thumbnail: '/api/placeholder/200/112',
        duration: 8,
        watScore: 78.2,
        isAIGenerated: true,
        tags: ['hook', 'scroll-stopper'],
      },
      {
        id: 'ai-2',
        name: 'AI Product Demo',
        thumbnail: '/api/placeholder/200/112',
        duration: 22,
        watScore: 81.5,
        isAIGenerated: true,
        tags: ['demo', 'education'],
      }
    ];
    clips.push(...aiClips);

    return clips;
  }, [strategy]);

  // Get clips by tab
  const getClipsByTab = useCallback((tab: string) => {
    switch (tab) {
      case 'mediamax':
        return mockClips.filter(clip => clip.isMediaMax);
      case 'ai':
        return mockClips.filter(clip => clip.isAIGenerated);
      case 'upload':
        return mockClips.filter(clip => !clip.isMediaMax && !clip.isAIGenerated);
      default:
        return [];
    }
  }, [mockClips]);

  // Handle clip assignment to modules
  const handleClipAssign = useCallback((clipId: string, moduleId: ModuleType) => {
    const clip = mockClips.find(c => c.id === clipId);
    if (!clip) return;

    setModuleClips(prev => ({
      ...prev,
      [moduleId]: [...prev[moduleId], { ...clip, module: moduleId }]
    }));
  }, [mockClips]);

  // Handle clip removal from modules
  const handleClipRemove = useCallback((clipId: string, moduleId: ModuleType) => {
    setModuleClips(prev => ({
      ...prev,
      [moduleId]: prev[moduleId].filter(clip => clip.id !== clipId)
    }));
  }, []);

  // AI Command execution
  const handleExecuteCommand = useCallback((command: AICommand) => {
    switch (command.command) {
      case 'assignClip':
        // Handle AI clip assignment
        console.log('AI assigning clip:', command);
        break;
      case 'suggestModule':
        // Handle AI module suggestion
        console.log('AI suggesting module:', command);
        break;
      default:
        console.log('Unknown AI command:', command);
    }
  }, []);

  // Handle resizing functionality
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
    document.body.classList.add('resizing');
    
    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = window.innerWidth - e.clientX;
      const minWidth = 280; // Minimum width
      const maxWidth = window.innerWidth * 0.6; // Maximum 60% of screen
      
      setCopilotWidth(Math.max(minWidth, Math.min(maxWidth, newWidth)));
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.classList.remove('resizing');
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, []);

  // Update CSS custom property for copilot width
  useEffect(() => {
    document.documentElement.style.setProperty('--copilot-width', `${copilotWidth}px`);
  }, [copilotWidth]);

  // Check if ready to proceed
  const canProceed = useMemo(() => {
    const requiredModules: ModuleType[] = ['scroll', 'brand', 'education'];
    return requiredModules.every(moduleId => moduleClips[moduleId].length > 0);
  }, [moduleClips]);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Strategy Summary Bar */}
      {strategy && (
        <div className="glass-card p-3 mb-4 border border-white/20 rounded-lg flex-shrink-0">
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <span className="text-white/80 font-medium accessibility-enhanced">Strategy:</span>
            
            <span className="px-2 py-1 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded text-white border border-white/20 text-xs">
              📂 {strategy.category}
            </span>
            
            {strategy.brands.length > 0 && (
              <span className="px-2 py-1 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded text-white border border-white/20 text-xs">
                🏢 {strategy.brands.length} brand{strategy.brands.length !== 1 ? 's' : ''}: {strategy.brands.slice(0, 2).join(', ')}{strategy.brands.length > 2 ? ` +${strategy.brands.length - 2}` : ''}
              </span>
            )}
            
            {strategy.objective && (
              <span className="px-2 py-1 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded text-white border border-white/20 text-xs">
                🎯 {strategy.objective}
              </span>
            )}
            
            {strategy.platforms.length > 0 && (
              <span className="px-2 py-1 bg-gradient-to-r from-pink-500/20 to-purple-500/20 rounded text-white border border-white/20 text-xs">
                📱 {strategy.platforms.length} platform{strategy.platforms.length !== 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Two-Column Layout */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full flex gap-6">
          
          {/* Left Column (~1/3 width) */}
          <div className="w-1/3 flex flex-col space-y-4 overflow-hidden">
            
            {/* Modules Panel */}
            <div className="flex-shrink-0">
              <ModuleSidebar 
                modules={MODULES}
                moduleClips={moduleClips}
                onClipRemove={handleClipRemove}
              />
            </div>
            
            {/* Clip Library Section */}
            <div className="flex-1 overflow-hidden">
              <ClipLibraryTabs
                activeTab={activeTab}
                onTabChange={setActiveTab}
                clips={getClipsByTab(activeTab)}
                strategy={strategy}
              />
            </div>
            
          </div>

          {/* Right Column (~2/3 width) */}
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* Pipeline Bar */}
            <div className="flex-shrink-0 mb-6">
              <div className="glass-card p-4 border border-white/20 rounded-xl relative overflow-hidden">
                
                {/* Celebration Overlay */}
                {canProceed && Object.values(moduleClips).every(clips => clips.length > 0) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-orange-500/20 to-red-500/20 animate-pulse pointer-events-none rounded-xl" />
                )}
                
                <div className="flex items-center justify-center space-x-6 relative z-10">
                  
                  {/* Clip Modules Icon */}
                  <div className={`pipeline-stage ${Object.values(moduleClips).some(clips => clips.length > 0) ? 'active stage-blue' : ''}`}>
                    <div className="pipeline-icon">
                      🎬
                    </div>
                    <span className="pipeline-label">Clip Modules</span>
                  </div>
                  
                  {/* Animated Flow Arrow */}
                  <div className={`pipeline-arrow ${Object.values(moduleClips).some(clips => clips.length > 0) ? 'flowing' : ''}`}>
                    <div className="arrow-container">
                      <span className="arrow-base">▶️</span>
                      <div className="flow-glow" />
                    </div>
                  </div>
                  
                  {/* Combination Engine */}
                  <div className={`pipeline-stage ${canProceed ? 'active spinning stage-gold' : ''}`}>
                    <div className="pipeline-icon gear-icon">
                      {Object.values(moduleClips).every(clips => clips.length > 0) ? '🏆' : '⚙️'}
                    </div>
                    <span className="pipeline-label">
                      {Object.values(moduleClips).every(clips => clips.length > 0) ? 'Ready!' : 'Combination Engine'}
                    </span>
                  </div>
                  
                  {/* Animated Flow Arrow */}
                  <div className={`pipeline-arrow ${canProceed ? 'flowing' : ''}`}>
                    <div className="arrow-container">
                      <span className="arrow-base">▶️</span>
                      <div className="flow-glow" />
                    </div>
                  </div>
                  
                  {/* Preview Grid */}
                  <div className={`pipeline-stage ${canProceed ? 'active pulsing stage-magenta' : ''}`}>
                    <div className="pipeline-icon">
                      🎞️
                    </div>
                    <span className="pipeline-label">Preview Grid</span>
                    
                    {/* Mini preview cards that appear when ready */}
                    {canProceed && (
                      <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-1">
                        <div className="mini-preview-card bounce-1" />
                        <div className="mini-preview-card bounce-2" />
                        <div className="mini-preview-card bounce-3" />
                      </div>
                    )}
                  </div>
                  
                </div>
                
                {/* Trophy Ribbon for Complete State */}
                {Object.values(moduleClips).every(clips => clips.length > 0) && (
                  <div className="mt-4 text-center">
                    <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-4 py-2 rounded-full font-bold text-sm shadow-lg animate-bounce">
                      <span>🏆</span>
                      <span>Ready for your red-carpet premiere!</span>
                      <span>✨</span>
                    </div>
                  </div>
                )}
                
                {/* Live Combinations Formula */}
                {canProceed && (
                  <div className="mt-3 text-center">
                    <div className="inline-flex items-center space-x-2 text-sm">
                      <span className="text-white/70">Combinations:</span>
                      <span className="combo-factor stage-blue-glow">{moduleClips.scroll.length}</span>
                      <span className="text-white/50">×</span>
                      <span className="combo-factor stage-blue-glow">{moduleClips.brand.length}</span>
                      <span className="text-white/50">×</span>
                      <span className="combo-factor stage-blue-glow">{moduleClips.education.length}</span>
                      <span className="text-white/50">×</span>
                      <span className="combo-factor stage-blue-glow">{moduleClips.proof.length || 1}</span>
                      <span className="text-white/50">×</span>
                      <span className="combo-factor stage-blue-glow">{moduleClips.cta.length || 1}</span>
                      <span className="text-white/50">=</span>
                      <span className="combo-total stage-gold-glow">
                        {moduleClips.scroll.length * moduleClips.brand.length * moduleClips.education.length * (moduleClips.proof.length || 1) * (moduleClips.cta.length || 1)}
                      </span>
                      <span className="text-white/70">combos</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Module Canvas */}
            <div className={`transition-all duration-300 flex-1 ${
              isCopilotOpen && !isMinimized 
                ? 'mr-96' 
                : isCopilotOpen && isMinimized
                ? 'mr-12'
                : ''
            }`}>
              <ModuleCanvas
                modules={MODULES}
                moduleClips={moduleClips}
                onClipAssign={handleClipAssign}
                onClipRemove={handleClipRemove}
              />
            </div>

            {/* AI Copilot Panel */}
            {isCopilotOpen && (
              <div 
                className={`copilot-panel border-l border-white/10 flex-shrink-0 relative ${
                  isMinimized ? 'minimized' : ''
                } ${isResizing ? 'resizing' : ''}`}
                data-width={copilotWidth}
              >
                {/* Resize Handle */}
                {!isMinimized && (
                  <div
                    className="resize-handle"
                    onMouseDown={handleMouseDown}
                  />
                )}
                
                <AICopilotChat 
                  onExecuteCommand={handleExecuteCommand}
                  isMinimized={isMinimized}
                  onToggleMinimize={() => setIsMinimized(!isMinimized)}
                  subtitle="AI Module Director Assistant"
                />
              </div>
            )}
            
          </div>
          
        </div>
      </div>

      {/* AI Copilot Toggle Button */}
      {!isCopilotOpen && (
        <button
          onClick={() => setIsCopilotOpen(true)}
          className="fixed bottom-6 right-6 bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white p-4 rounded-full shadow-xl hover-lift focus-ring z-50"
          aria-label="Open AI Copilot"
        >
          <span className="text-xl">🤖</span>
        </button>
      )}

      {/* Enhanced Continue Button - Fixed Footer Bar */}
      <div className="flex-shrink-0 bg-gradient-to-r from-indigo-900/80 to-purple-900/80 backdrop-blur-md border-t border-white/10 p-4">
        
        {/* Progress Meter */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-sm text-white/80 mb-2">
            <span>Progress</span>
            <span className="font-bold">
              {Object.values(moduleClips).filter(clips => clips.length > 0).length}/6 modules seeded
            </span>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
            <div 
              className={`h-full bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full transition-all duration-500 ease-out progress-bar-${Math.round((Object.values(moduleClips).filter(clips => clips.length > 0).length / 6) * 10)}`}
            />
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          
          {/* Module Status Pills */}
          <div className="flex items-center space-x-3">
            <div className="flex space-x-1">
              {MODULES.map((module) => {
                const hasClips = moduleClips[module.id].length > 0;
                return (
                  <div
                    key={module.id}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      hasClips 
                        ? 'bg-green-400 animate-pulse' 
                        : 'bg-white/20'
                    }`}
                    title={`${module.name}: ${moduleClips[module.id].length} clips`}
                  />
                );
              })}
            </div>
          </div>

          {/* Generate Button with Enhanced Animation */}
          <button
            onClick={onNext}
            disabled={!canProceed}
            className={`px-8 py-3 rounded-xl font-bold transition-all duration-300 focus-ring flex items-center space-x-2 ${
              canProceed
                ? 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black shadow-lg hover:shadow-xl transform hover:scale-105 generate-ready-pulse'
                : 'glass-card border border-white/20 text-white/60 cursor-not-allowed opacity-60'
            }`}
            aria-describedby={!canProceed ? 'generate-help' : undefined}
          >
            {canProceed ? (
              <>
                <span className="text-lg">🎬</span>
                <span>Generate {
                  moduleClips.scroll.length * 
                  moduleClips.brand.length * 
                  moduleClips.education.length * 
                  (moduleClips.proof.length || 1) * 
                  (moduleClips.cta.length || 1)
                } Combinations</span>
                <span className="text-lg">✨</span>
              </>
            ) : (
              <>
                <span className="text-lg">🔒</span>
                <span>Add clips to required modules</span>
              </>
            )}
          </button>
        </div>
        
        {/* Accessibility Helper Text */}
        {!canProceed && (
          <div id="generate-help" className="sr-only">
            Button disabled until all required modules (Scroll Stopper, Brand Builder, Education) have at least one clip
          </div>
        )}
        
        {/* Ready for premiere message */}
        {canProceed && Object.values(moduleClips).every(clips => clips.length > 0) && (
          <div className="mt-3 text-center">
            <div className="text-sm text-yellow-200 italic animate-bounce">
              🎉 Ready for your red-carpet premiere!
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrganizeClipsPage;
