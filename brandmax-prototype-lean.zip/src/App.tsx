import { useState, useCallback, useEffect } from 'react';
import CombinationControls from './components/CombinationControls';
import StrategyForm from './components/StrategyForm';
import AICopilotChat from './components/AICopilotChat';
import OrganizeClipsPage from './pages/OrganizeClipsPage';
import { CopilotProvider } from './contexts/CopilotContext';
import type { AICommand } from './contexts/CopilotContext';

// Enhanced data types with better typing
type ModuleKey = 'scroll' | 'brand' | 'education' | 'evidence' | 'cta' | 'audio';

interface ClipData {
  id: string;
  name: string;
  duration: number;
  thumbnail: string;
  module: ModuleKey;
  engagementScore: number;
  isAIGenerated?: boolean;
}

interface VideoCombination {
  id: string;
  clips: ClipData[];
  estimatedWAT: number;
  totalDuration: number;
  created: Date;
}

type StepType = 'strategy' | 'organize' | 'combinations' | 'deploy';

function AppContent() {
  const [currentStep, setCurrentStep] = useState<StepType>('strategy');
  
  // Strategy state (needed for CombinationControls)
  const [maxDuration] = useState(60);
  
  // Combination State
  const [combinations, setCombinations] = useState<VideoCombination[]>([]);

  // AI Copilot state for resizing and minimizing
  const [copilotWidth, setCopilotWidth] = useState(384); // 384px = w-96
  const [isMinimized, setIsMinimized] = useState(false);
  const [isResizing, setIsResizing] = useState(false);

  // AI Command execution handler
  const handleExecuteCommand = (command: AICommand) => {
    switch (command.command) {
      case 'selectCategory':
        // Handle category selection in StrategyForm
        setCurrentStep('strategy');
        break;
      case 'toggleBrand':
        // Handle brand toggle in StrategyForm
        break;
      case 'setObjective':
        // Handle objective setting in StrategyForm
        break;
      case 'openAccordion':
        // Handle accordion opening in StrategyForm
        break;
      default:
        console.log('Unknown command:', command);
    }
  };

  // Handle resizing functionality
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
    document.body.classList.add('resizing');
    
    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = window.innerWidth - e.clientX;
      const minWidth = 280; // Minimum width
      const maxWidth = window.innerWidth * 0.6; // Maximum 60% of screen
      
      setCopilotWidth(Math.max(minWidth, Math.min(maxWidth, newWidth)));
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.classList.remove('resizing');
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  // Update CSS custom property for copilot width
  useEffect(() => {
    document.documentElement.style.setProperty('--copilot-width', `${copilotWidth}px`);
  }, [copilotWidth]);

  const steps = [
    { key: 'strategy', icon: '🎯', label: 'Strategy', description: 'Define audience & goals' },
    { key: 'organize', icon: '📁', label: 'Organize', description: 'Upload & categorize clips' },
    { key: 'combinations', icon: '🔄', label: 'Combinations', description: 'Generate video variations' },
    { key: 'deploy', icon: '🚀', label: 'Deploy', description: 'Launch campaigns' }
  ];

  const currentStepIndex = steps.findIndex(step => step.key === currentStep);

  // Memoized handlers to prevent unnecessary re-renders
  const canProceedToNext = useCallback(() => {
    switch (currentStep) {
      case 'strategy':
        return true; // Strategy form has its own validation
      case 'organize':
        return true; // OrganizeClipsPage handles its own validation
      case 'combinations':
        return combinations.length > 0;
      default:
        return false;
    }
  }, [currentStep, combinations.length]);

  // Dynamic gradient based on current step for cinematic feel
  const getStepGradient = (step: StepType) => {
    switch (step) {
      case 'strategy': return 'step-gradient-strategy';
      case 'organize': return 'step-gradient-organize';
      case 'combinations': return 'step-gradient-combinations';
      case 'deploy': return 'step-gradient-deploy';
      default: return 'step-gradient-strategy';
    }
  };

  return (
    <div className={`h-screen flex flex-col overflow-hidden transition-all duration-1000 ${getStepGradient(currentStep)}`}>
      {/* Background orbs for visual interest */}
      <div className="bg-orb-1"></div>
      <div className="bg-orb-2"></div>
      <div className="bg-orb-3"></div>
      
      {/* Fixed Header - 4rem height */}
      <header className="header-height sticky top-0 z-50 glass-panel border-b-white-10 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between gap-4">
          {/* Brand Title - Clean and prominent */}
          <div className="flex items-center flex-shrink-0 min-w-0">
            <button 
              onClick={() => setCurrentStep('strategy')}
              className="brand-button text-left hover:scale-105 transition-all duration-300 focus-ring cursor-pointer block"
              aria-label="Return to home"
            >
              <h1 className="brand-title text-xl sm:text-2xl leading-tight">
                Brand<span>*</span>MAX{currentStep === 'organize' && ' – Director Mode'}
              </h1>
              <p className="brand-subtitle text-xs sm:text-sm animate-slide-in-up hidden sm:block">
                {currentStep === 'organize' ? 'Organize Your Clips' : 'Create and Build Your Brand with AI'}
              </p>
            </button>
          </div>

          {/* Enhanced Progress Bar - Clear and Guided */}
          <div className="hidden lg:flex flex-col items-center space-y-1 flex-shrink-0 px-4">
            <div className="text-xs text-white/80 font-medium accessibility-enhanced">
              Step {currentStepIndex + 1} of {steps.length}
            </div>
            <div className="flex items-center space-x-2">
              {steps.map((step, index) => (
                <div key={step.key} className="flex items-center">
                  <button
                    onClick={() => setCurrentStep(step.key as StepType)}
                    disabled={index > currentStepIndex + 1}
                    className={`relative flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold transition-all duration-300 ${
                      currentStep === step.key
                        ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-white shadow-lg scale-110 ring-2 ring-white/30'
                        : index <= currentStepIndex
                        ? 'bg-gradient-to-r from-green-400 to-emerald-500 text-white shadow-md hover:scale-105'
                        : 'bg-white/10 text-white/50 cursor-not-allowed'
                    }`}
                    aria-label={`${step.label} - ${index <= currentStepIndex ? 'Completed' : index === currentStepIndex + 1 ? 'Available' : 'Locked'}`}
                  >
                    {index < currentStepIndex ? (
                      <span>✓</span>
                    ) : (
                      <span>{index + 1}</span>
                    )}
                    
                    {/* Tooltip on hover */}
                    <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-black/80 text-white text-xs py-1 px-2 rounded whitespace-nowrap opacity-0 hover:opacity-100 pointer-events-none transition-opacity z-10">
                      {step.label}
                    </div>
                  </button>
                  
                  {/* Progress line between steps */}
                  {index < steps.length - 1 && (
                    <div className={`w-6 h-0.5 mx-1 transition-all duration-500 ${
                      index < currentStepIndex 
                        ? 'bg-gradient-to-r from-green-400 to-emerald-500' 
                        : 'bg-white/20'
                    }`} />
                  )}
                </div>
              ))}
            </div>
            <div className="text-xs text-white/80 font-medium text-center">
              {steps[currentStepIndex]?.label}: {steps[currentStepIndex]?.description}
            </div>
          </div>

          {/* Mobile Progress - Enhanced with current step info */}
          <div className="flex lg:hidden flex-col items-center space-y-1 flex-shrink-0">
            <div className="text-xs text-white/80 font-medium accessibility-enhanced">
              {currentStepIndex + 1}/{steps.length} - {steps[currentStepIndex]?.label}
            </div>
            <div className="flex items-center space-x-1">
              {steps.map((step, index) => (
                <div key={`mobile-${step.key}`} className="flex items-center">
                  <button
                    onClick={() => setCurrentStep(step.key as StepType)}
                    disabled={index > currentStepIndex + 1}
                    className={`w-3 h-3 rounded-full transition-all ${
                      currentStep === step.key
                        ? 'bg-cyan-400 scale-125 ring-1 ring-white/30'
                        : index <= currentStepIndex
                        ? 'bg-green-400 hover:scale-110'
                        : 'bg-white/20'
                    }`}
                    aria-label={`Step ${index + 1}: ${step.label}`}
                  />
                  {index < steps.length - 1 && (
                    <div className={`w-2 h-0.5 mx-0.5 ${
                      index < currentStepIndex ? 'bg-green-400' : 'bg-white/20'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>
      </header>

      {/* Main Content - Zero Scroll Layout with Two-Column Split */}
      <main className="flex-1 overflow-hidden">
        <div className="h-full flex">
          {/* Left Column - Main Content (70% width) */}
          <div className="flex-1 overflow-hidden">
            <div className="max-w-none mx-auto h-full flex flex-col px-4">
          {/* Step 1: Strategy Setup */}
          {currentStep === 'strategy' && (
            <div className="animate-fade-in h-full overflow-hidden">
              <StrategyForm 
                onNext={() => setCurrentStep('organize')}
              />
            </div>
          )}

          {/* Step 2: Organize Your Clips */}
          {currentStep === 'organize' && (
            <div className="animate-fade-in h-full overflow-hidden">
              <OrganizeClipsPage 
                strategy={{
                  category: 'Hair Care', // TODO: Get from actual strategy state
                  brands: ['Pantene', 'Head & Shoulders'],
                  objective: 'Build',
                  platforms: ['tiktok', 'instagram'],
                  voiceTone: 'influencer',
                  targetAudience: 'gen-z'
                }}
                onNext={() => setCurrentStep('combinations')}
              />
            </div>
          )}

          {/* Step 3: Generate Combinations */}
          {currentStep === 'combinations' && (
            <div className="animate-fade-in h-full flex flex-col">
              <div className="glass-panel p-6 mb-4 flex-shrink-0">
                <h2 className="text-2xl font-bold text-accessible mb-2 flex items-center">
                  <span className="mr-3" aria-hidden="true">🔄</span>
                  Step 3: Generate Video Combinations
                </h2>
                <p className="text-accessible-muted mb-4">
                  AI-powered combinations optimized for maximum Weighted Attention Time based on your strategy.
                </p>
              </div>

              <div className="flex-1 overflow-hidden">
                <CombinationControls
                  clipsByModule={{
                    scroll: [],
                    brand: [],
                    education: [],
                    evidence: [],
                    cta: [],
                    audio: []
                  }}
                  combinations={combinations}
                  selectedCombination={null}
                  maxDuration={maxDuration}
                  onGenerateCombinations={() => {
                    // Generate some sample combinations
                    const newCombinations: VideoCombination[] = [
                      {
                        id: '1',
                        clips: [],
                        estimatedWAT: 85.2,
                        totalDuration: 30,
                        created: new Date()
                      }
                    ];
                    setCombinations(newCombinations);
                  }}
                  onSelectCombination={() => {}}
                />
              </div>
            </div>
          )}

          {/* Step 4: Deploy Campaign */}
          {currentStep === 'deploy' && (
            <div className="animate-fade-in h-full flex flex-col">
              <div className="glass-panel p-6 mb-4 flex-shrink-0">
                <h2 className="text-2xl font-bold text-accessible mb-2 flex items-center">
                  <span className="mr-3" aria-hidden="true">🚀</span>
                  Step 4: Deploy Your Campaign
                </h2>
                <p className="text-accessible-muted mb-4">
                  Launch your optimized video combinations across multiple platforms with AI-powered scheduling.
                </p>
              </div>

              <div className="flex-1 flex items-center justify-center">
                <button className="btn-primary px-12 py-4 text-xl font-bold hover-lift focus-ring">
                  <span className="mr-3" aria-hidden="true">🚀</span>
                  Launch Campaign
                  <span className="ml-3" aria-hidden="true">✨</span>
                </button>
              </div>
            </div>
          )}
            </div>
          </div>
          
          {/* Right Column - AI Copilot Chat (Resizable) */}
          <div 
            className={`copilot-panel border-l border-white/10 flex-shrink-0 relative ${
              isMinimized ? 'minimized' : ''
            } ${isResizing ? 'resizing' : ''}`}
            data-width={copilotWidth}
          >
            {/* Resize Handle */}
            {!isMinimized && (
              <div
                className="resize-handle"
                onMouseDown={handleMouseDown}
              />
            )}
            
            <AICopilotChat 
              onExecuteCommand={handleExecuteCommand}
              isMinimized={isMinimized}
              onToggleMinimize={toggleMinimize}
              subtitle={currentStep === 'organize' ? 'AI Module Director Assistant' : 'Interactive Strategy Assistant'}
            />
          </div>
        </div>
      </main>

      {/* Sticky Footer with Continue Button */}
      <footer className="footer-height bg-black/50 backdrop-blur-sm border-t border-white/20 flex items-center justify-center px-4 flex-shrink-0">
        <button
          onClick={() => {
            if (currentStep === 'strategy') setCurrentStep('organize');
            else if (currentStep === 'organize') setCurrentStep('combinations');
            else if (currentStep === 'combinations') setCurrentStep('deploy');
          }}
          disabled={!canProceedToNext()}
          className={`px-8 py-3 text-lg font-bold rounded-lg transition-all focus-ring ${
            canProceedToNext()
              ? 'btn-primary hover-lift animate-pulse'
              : 'glass-card border border-white/20 text-accessible-muted cursor-not-allowed opacity-50'
          }`}
        >
          {currentStep === 'strategy' && 'Continue to Organize Clips →'}
          {currentStep === 'organize' && 'Generate Combinations →'}
          {currentStep === 'combinations' && 'Deploy Campaign →'}
          {currentStep === 'deploy' && 'Campaign Ready ✨'}
        </button>
      </footer>
    </div>
  );
}

// Main App wrapper with CopilotProvider
function App() {
  return (
    <CopilotProvider>
      <AppContent />
    </CopilotProvider>
  );
}

export default App;
