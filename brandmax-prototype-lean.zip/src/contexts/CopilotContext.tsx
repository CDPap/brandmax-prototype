import { createContext, useContext, useReducer } from 'react';
import type { ReactNode } from 'react';

// Types for AI commands
export interface AICommand {
  command: 'selectCategory' | 'toggleBrand' | 'selectProduct' | 'setObjective' | 'togglePlatform' | 'setVoiceTone' | 'setTargetAudience' | 'openAccordion' | 'closeAccordion' | 'assignClip' | 'suggestModule' | 'pinClip' | 'classifyClip' | 'rebalanceClips';
  value: string | number | boolean;
  target?: string; // For accordion actions
  clipId?: string; // For clip-related actions
  moduleId?: string; // For module-related actions
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  commands?: AICommand[];
}

interface CopilotState {
  isOpen: boolean;
  messages: ChatMessage[];
  isTyping: boolean;
  currentStep: string;
}

interface CopilotActions {
  openCopilot: () => void;
  closeCopilot: () => void;
  toggleCopilot: () => void;
  addMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  executeCommand: (command: AICommand) => void;
  setTyping: (typing: boolean) => void;
  setCurrentStep: (step: string) => void;
}

type CopilotAction = 
  | { type: 'OPEN_COPILOT' }
  | { type: 'CLOSE_COPILOT' }
  | { type: 'TOGGLE_COPILOT' }
  | { type: 'ADD_MESSAGE'; payload: Omit<ChatMessage, 'id' | 'timestamp'> }
  | { type: 'SET_TYPING'; payload: boolean }
  | { type: 'SET_CURRENT_STEP'; payload: string };

const initialState: CopilotState = {
  isOpen: false,
  messages: [
    {
      id: 'welcome',
      type: 'ai',
      content: "Hi! I'm your Brand*MAX AI assistant. I can help you set up your strategy by suggesting brands, products, and objectives based on your goals. What would you like to create today?",
      timestamp: new Date(),
    }
  ],
  isTyping: false,
  currentStep: 'strategy',
};

function copilotReducer(state: CopilotState, action: CopilotAction): CopilotState {
  switch (action.type) {
    case 'OPEN_COPILOT':
      return { ...state, isOpen: true };
    case 'CLOSE_COPILOT':
      return { ...state, isOpen: false };
    case 'TOGGLE_COPILOT':
      return { ...state, isOpen: !state.isOpen };
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: [
          ...state.messages,
          {
            ...action.payload,
            id: `msg-${Date.now()}`,
            timestamp: new Date(),
          }
        ]
      };
    case 'SET_TYPING':
      return { ...state, isTyping: action.payload };
    case 'SET_CURRENT_STEP':
      return { ...state, currentStep: action.payload };
    default:
      return state;
  }
}

const CopilotContext = createContext<{
  state: CopilotState;
  actions: CopilotActions;
} | null>(null);

export function CopilotProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(copilotReducer, initialState);

  const actions: CopilotActions = {
    openCopilot: () => dispatch({ type: 'OPEN_COPILOT' }),
    closeCopilot: () => dispatch({ type: 'CLOSE_COPILOT' }),
    toggleCopilot: () => dispatch({ type: 'TOGGLE_COPILOT' }),
    addMessage: (message) => dispatch({ type: 'ADD_MESSAGE', payload: message }),
    setTyping: (typing) => dispatch({ type: 'SET_TYPING', payload: typing }),
    setCurrentStep: (step) => dispatch({ type: 'SET_CURRENT_STEP', payload: step }),
    executeCommand: (command) => {
      // This will be implemented by the components that consume this context
      console.log('Executing command:', command);
    },
  };

  return (
    <CopilotContext.Provider value={{ state, actions }}>
      {children}
    </CopilotContext.Provider>
  );
}

export function useCopilot() {
  const context = useContext(CopilotContext);
  if (!context) {
    throw new Error('useCopilot must be used within a CopilotProvider');
  }
  return context;
}

// AI Response Generator (simulated)
export async function generateAIResponse(userMessage: string): Promise<{ content: string; commands?: AICommand[] }> {
  // Simulate AI thinking delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

  const message = userMessage.toLowerCase();
  
  // Hair care example
  if (message.includes('hair') || message.includes('shampoo') || message.includes('pantene')) {
    return {
      content: "Perfect! I'll help you set up a hair care campaign. Let me select Hair Care category and add some popular brands for you.",
      commands: [
        { command: 'selectCategory', value: 'Hair Care' },
        { command: 'toggleBrand', value: 'Pantene' },
        { command: 'toggleBrand', value: 'Head & Shoulders' },
        { command: 'selectProduct', value: 'Shampoo' },
        { command: 'selectProduct', value: 'Conditioner' },
      ]
    };
  }

  // Beauty example
  if (message.includes('beauty') || message.includes('makeup') || message.includes('cosmetic')) {
    return {
      content: "Great choice! I'll set up a beauty campaign for you with some top beauty brands.",
      commands: [
        { command: 'selectCategory', value: 'Beauty' },
        { command: 'toggleBrand', value: 'Olay' },
        { command: 'toggleBrand', value: 'SK-II' },
        { command: 'setObjective', value: 'brand-awareness' },
      ]
    };
  }

  // Platform suggestions
  if (message.includes('tiktok') || message.includes('instagram') || message.includes('social')) {
    return {
      content: "I'll configure your campaign for social media platforms. TikTok and Instagram are perfect for engaging video content!",
      commands: [
        { command: 'togglePlatform', value: 'tiktok' },
        { command: 'togglePlatform', value: 'instagram' },
        { command: 'openAccordion', value: 'platforms', target: 'platforms' },
      ]
    };
  }

  // Voice tone suggestions
  if (message.includes('fun') || message.includes('playful') || message.includes('energetic')) {
    return {
      content: "I love that energy! Let me set a playful and energetic voice tone for your brand.",
      commands: [
        { command: 'setVoiceTone', value: 'playful' },
        { command: 'openAccordion', value: 'voice', target: 'voice' },
      ]
    };
  }

  // Generic helpful responses
  const responses = [
    "I can help you select the right brand category, choose products, and set up your campaign objectives. What specific area would you like assistance with?",
    "Let me know what type of campaign you're looking to create - I can suggest brands, platforms, and targeting options!",
    "I'm here to guide you through the strategy setup. Would you like me to recommend some popular brand combinations?",
    "Tell me more about your campaign goals, and I'll help configure the perfect setup for maximum engagement!"
  ];

  return {
    content: responses[Math.floor(Math.random() * responses.length)]
  };
}
