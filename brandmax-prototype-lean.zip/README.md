# Brand*MAX Prototype 🎬

A next-generation video content creation platform with AI-powered assistance and cinematic design.

## ✨ Features

- **🎯 Director Mode**: Organize clips with intuitive drag-and-drop interface
- **🤖 AI Copilot**: Intelligent assistant for strategy and content organization  
- **🎨 Cinematic UI**: Glass morphism design with enhanced accessibility
- **📱 Responsive**: Optimized for desktop and mobile experiences
- **⚡ Fast**: Built with Vite and React for optimal performance

## 🚀 Live Demo

🌐 **[View Live Application](https://CDPap.github.io/brandmax-prototype/)**

## 🛠️ Technology Stack

- **Frontend**: React 18 + TypeScript
- **Build Tool**: Vite 7
- **Styling**: Tailwind CSS + Custom CSS
- **Deployment**: GitHub Pages + Actions
- **AI Integration**: Context-aware copilot system

## 🎨 Design Highlights

- **Near-black cinematic backgrounds** for premium feel
- **Golden primary buttons** (#FFC600) for key actions  
- **Teal secondary buttons** (#14B8A6) for supporting actions
- **Module-specific color coding** for enhanced UX
- **WCAG AA accessibility compliance**

## 🏗️ Architecture

```
src/
├── components/          # React components
│   ├── ModuleSidebar.tsx    # Color-coded module organization
│   ├── ClipLibraryTabs.tsx  # Asset bank interface
│   ├── ModuleCanvas.tsx     # Target slots for clips
│   └── AICopilotChat.tsx    # AI assistant interface
├── contexts/           # React contexts
│   └── CopilotContext.tsx   # AI copilot state management
├── pages/             # Page components
│   └── OrganizeClipsPage.tsx # Main director mode interface
└── index.css          # 63KB+ of custom styling
```

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 🤖 AI Copilot Features

- **Strategy Assistance**: Helps configure brand campaigns
- **Content Organization**: Suggests optimal clip arrangements  
- **Platform Optimization**: Recommends platform-specific approaches
- **Voice Tone Guidance**: Assists with brand voice configuration

## 📋 Deployment

Automatic deployment via GitHub Actions:
- ✅ Builds on every push to `main`
- ✅ Deploys to GitHub Pages
- ✅ Zero configuration required

## 🎯 Project Vision

Transform video content creation with AI-powered assistance and professional-grade tooling, making high-quality content accessible to creators of all skill levels.

---

**Built with ❤️ for the creator economy**
