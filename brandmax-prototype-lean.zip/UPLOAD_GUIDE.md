# Brand*MAX GitHub Upload Guide

## Files to Upload Manually:

### Root Files (upload to main directory):
- package.json
- package-lock.json
- README.md
- LICENSE
- index.html
- vite.config.ts
- tsconfig.json
- tsconfig.app.json
- tsconfig.node.json
- tailwind.config.js
- postcss.config.js
- eslint.config.js
- vercel.json

### Create these files with paths:

#### .github/workflows/deploy.yml
(Copy content from your local file)

#### src/main.tsx
(Copy content from your local file)

#### src/App.tsx
(Copy content from your local file)

#### src/index.css
(Copy content from your local file)

#### src/vite-env.d.ts
(Copy content from your local file)

#### src/components/ModuleSidebar.tsx
#### src/components/ClipLibraryTabs.tsx
#### src/components/ModuleCanvas.tsx
#### src/components/ClipCard.tsx
#### src/components/AICopilotChat.tsx
#### src/components/ClipLibrary.tsx
#### src/components/CombinationControls.tsx
#### src/components/StrategyForm.tsx

#### src/contexts/CopilotContext.tsx

#### src/pages/OrganizeClipsPage.tsx

#### src/config/strategy.ts

#### src/assets/react.svg

#### public/vite.svg

## Quick Method:
1. Go to Add file → Create new file
2. Type the full path (e.g., "src/components/ModuleSidebar.tsx")
3. Paste the file content
4. Commit
5. Repeat for each file
